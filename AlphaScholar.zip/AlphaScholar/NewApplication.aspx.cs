﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Web.UI;

public partial class NewApplication : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ApplicantEmail"] == null)
        {
            Response.Redirect("Home.aspx");
            return;
        }

        if (!IsPostBack)
        {
            if (!IsApplicationSubmissionEnabled())
            {
                btnSubmit.Enabled = false;
                lblMessage.Text = "Application submission is currently disabled by the admin.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Visible = true;
            }
        }
    }

    protected void SubmitApplication(object sender, EventArgs e)
    {
        if (!IsApplicationSubmissionEnabled())
        {
            lblMessage.Text = "Application submission is currently disabled by the admin.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            lblMessage.Visible = true;
            return;
        }

        string applicantEmail = Session["ApplicantEmail"] as string;
        if (string.IsNullOrEmpty(applicantEmail))
        {
            lblMessage.Text = "Please log in to submit an application.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            return;
        }

        // Validate required fields
        if (string.IsNullOrEmpty(firstName.Text) || string.IsNullOrEmpty(lastName.Text) || string.IsNullOrEmpty(dob.Text) ||
            string.IsNullOrEmpty(mobileNumber.Text) || string.IsNullOrEmpty(gender.SelectedValue) || string.IsNullOrEmpty(motherName.Text) ||
            string.IsNullOrEmpty(category.SelectedValue) || string.IsNullOrEmpty(maritalStatus.SelectedValue) || string.IsNullOrEmpty(parentOccupation.Text) ||
            string.IsNullOrEmpty(annualIncome.Text) || string.IsNullOrEmpty(courseYear.Text) || string.IsNullOrEmpty(courseName.Text) ||
            string.IsNullOrEmpty(courseType.Text) || string.IsNullOrEmpty(presentInstitute.Text) || string.IsNullOrEmpty(presentCourseYear.Text) ||
            string.IsNullOrEmpty(presentCourseType.Text) || string.IsNullOrEmpty(percentage.Text) || string.IsNullOrEmpty(bankName.Text) ||
            string.IsNullOrEmpty(accountNumber.Text) || string.IsNullOrEmpty(ifscCode.Text) || string.IsNullOrEmpty(branchName.Text) ||
            string.IsNullOrEmpty(pincode.Text) || string.IsNullOrEmpty(address.Text) || string.IsNullOrEmpty(taluka.Text) ||
            string.IsNullOrEmpty(district.Text) || string.IsNullOrEmpty(state.Text) || string.IsNullOrEmpty(currentAddress.Text) ||
            string.IsNullOrEmpty(email.Text))
        {
            lblMessage.Text = "Error: All required fields must be filled.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            return;
        }

        // Validate compulsory file uploads
        if (!photoUpload.HasFile || !idProofUpload.HasFile || !marksheetUpload.HasFile ||
            !incomeCertUpload.HasFile || !bankPassbookUpload.HasFile || !casteCertUpload.HasFile)
        {
            lblMessage.Text = "Error: All documents (Photo, ID Proof, Marksheet, Income Certificate, Bank Passbook, Caste Certificate) are required.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            return;
        }

        if (!System.Text.RegularExpressions.Regex.IsMatch(mobileNumber.Text, @"^\d{10}$"))
        {
            lblMessage.Text = "Error: Mobile number must be a 10-digit number.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            return;
        }

        decimal parsedAnnualIncome;
        if (!decimal.TryParse(annualIncome.Text, out parsedAnnualIncome) || parsedAnnualIncome <= 0)
        {
            lblMessage.Text = "Error: Annual Family Income must be a valid positive number.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            return;
        }

        decimal parsedPercentage;
        if (!decimal.TryParse(percentage.Text, out parsedPercentage) || parsedPercentage < 0 || parsedPercentage > 100)
        {
            lblMessage.Text = "Error: Percentage must be a valid number between 0 and 100.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            return;
        }

        int parsedPincode;
        if (!int.TryParse(pincode.Text, out parsedPincode) || parsedPincode <= 0)
        {
            lblMessage.Text = "Error: Pincode must be a valid positive number.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            return;
        }

        decimal? parsedExamFees = null;
        if (!string.IsNullOrEmpty(examFees.Text))
        {
            decimal tempExamFees;
            if (!decimal.TryParse(examFees.Text, out tempExamFees) || tempExamFees < 0)
            {
                lblMessage.Text = "Error: Exam Fees must be a valid non-negative number.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }
            parsedExamFees = tempExamFees;
        }

        decimal? parsedAdmissionFees = null;
        if (!string.IsNullOrEmpty(admissionFees.Text))
        {
            decimal tempAdmissionFees;
            if (!decimal.TryParse(admissionFees.Text, out tempAdmissionFees) || tempAdmissionFees < 0)
            {
                lblMessage.Text = "Error: Admission Fees must be a valid non-negative number.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }
            parsedAdmissionFees = tempAdmissionFees;
        }

        string fullName = (firstName.Text + " " + middleName.Text + " " + lastName.Text).Trim();
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;

        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                // Insert with placeholder paths first to get ApplicationID
                string insertQuery = @"
                    INSERT INTO Applications (FullName, DOB, Email, Phone, Gender, MotherName, Category, MaritalStatus, ParentOccupation, 
                                             AnnualFamilyIncome, IsOrphan, CourseYear, CourseName, CourseType, PreviousEducation, ExamFees, 
                                             AdmissionFees, PresentInstitute, PresentCourseYear, PresentCourseType, Percentage, BankName, 
                                             AccountNumber, IFSCCode, BranchName, Pincode, Address, Taluka, District, State, CurrentAddress, 
                                             PhotoPath, IdProofPath, MarksheetPath, IncomePath, BankPassbookPath, CasteCertPath, 
                                             SubmissionDate, Status) 
                    OUTPUT INSERTED.ApplicationID
                    VALUES (@FullName, @DOB, @Email, @Phone, @Gender, @MotherName, @Category, @MaritalStatus, @ParentOccupation, 
                            @AnnualFamilyIncome, @IsOrphan, @CourseYear, @CourseName, @CourseType, @PreviousEducation, @ExamFees, 
                            @AdmissionFees, @PresentInstitute, @PresentCourseYear, @PresentCourseType, @Percentage, @BankName, 
                            @AccountNumber, @IFSCCode, @BranchName, @Pincode, @Address, @Taluka, @District, @State, @CurrentAddress, 
                            @PhotoPath, @IdProofPath, @MarksheetPath, @IncomePath, @BankPassbookPath, @CasteCertPath, 
                            @SubmissionDate, @Status)";

                using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@FullName", fullName);
                    cmd.Parameters.AddWithValue("@DOB", dob.Text);
                    cmd.Parameters.AddWithValue("@Email", applicantEmail.ToLower());
                    cmd.Parameters.AddWithValue("@Phone", mobileNumber.Text);
                    cmd.Parameters.AddWithValue("@Gender", gender.SelectedValue);
                    cmd.Parameters.AddWithValue("@MotherName", motherName.Text);
                    cmd.Parameters.AddWithValue("@Category", category.SelectedValue);
                    cmd.Parameters.AddWithValue("@MaritalStatus", maritalStatus.SelectedValue);
                    cmd.Parameters.AddWithValue("@ParentOccupation", parentOccupation.Text);
                    cmd.Parameters.AddWithValue("@AnnualFamilyIncome", parsedAnnualIncome);
                    cmd.Parameters.AddWithValue("@IsOrphan", isOrphan.Checked);
                    cmd.Parameters.AddWithValue("@CourseYear", courseYear.Text);
                    cmd.Parameters.AddWithValue("@CourseName", courseName.Text);
                    cmd.Parameters.AddWithValue("@CourseType", courseType.Text);
                    cmd.Parameters.AddWithValue("@PreviousEducation", string.IsNullOrEmpty(previousEducation.Text) ? (object)DBNull.Value : previousEducation.Text);
                    cmd.Parameters.AddWithValue("@ExamFees", (object)parsedExamFees ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@AdmissionFees", (object)parsedAdmissionFees ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@PresentInstitute", presentInstitute.Text);
                    cmd.Parameters.AddWithValue("@PresentCourseYear", presentCourseYear.Text);
                    cmd.Parameters.AddWithValue("@PresentCourseType", presentCourseType.Text);
                    cmd.Parameters.AddWithValue("@Percentage", parsedPercentage);
                    cmd.Parameters.AddWithValue("@BankName", bankName.Text);
                    cmd.Parameters.AddWithValue("@AccountNumber", accountNumber.Text);
                    cmd.Parameters.AddWithValue("@IFSCCode", ifscCode.Text);
                    cmd.Parameters.AddWithValue("@BranchName", branchName.Text);
                    cmd.Parameters.AddWithValue("@Pincode", parsedPincode);
                    cmd.Parameters.AddWithValue("@Address", address.Text);
                    cmd.Parameters.AddWithValue("@Taluka", taluka.Text); // Fixed typo here
                    cmd.Parameters.AddWithValue("@District", district.Text);
                    cmd.Parameters.AddWithValue("@State", state.Text);
                    cmd.Parameters.AddWithValue("@CurrentAddress", currentAddress.Text);
                    cmd.Parameters.AddWithValue("@PhotoPath", "placeholder"); // Temporary placeholder
                    cmd.Parameters.AddWithValue("@IdProofPath", "placeholder");
                    cmd.Parameters.AddWithValue("@MarksheetPath", "placeholder");
                    cmd.Parameters.AddWithValue("@IncomePath", "placeholder");
                    cmd.Parameters.AddWithValue("@BankPassbookPath", "placeholder");
                    cmd.Parameters.AddWithValue("@CasteCertPath", "placeholder");
                    cmd.Parameters.AddWithValue("@SubmissionDate", DateTime.Now);
                    cmd.Parameters.AddWithValue("@Status", "Pending");

                    int applicationId = Convert.ToInt32(cmd.ExecuteScalar());

                    // Create ApplicationID folder and save files directly there
                    string uploadBaseDir = Server.MapPath("~/Uploads/");
                    string applicationDir = Path.Combine(uploadBaseDir, applicationId.ToString());
                    if (!Directory.Exists(applicationDir))
                    {
                        Directory.CreateDirectory(applicationDir);
                    }

                    string photoPath = SaveFile(photoUpload, applicationDir, applicationId);
                    string idProofPath = SaveFile(idProofUpload, applicationDir, applicationId);
                    string marksheetPath = SaveFile(marksheetUpload, applicationDir, applicationId);
                    string incomePath = SaveFile(incomeCertUpload, applicationDir, applicationId);
                    string bankPassbookPath = SaveFile(bankPassbookUpload, applicationDir, applicationId);
                    string casteCertPath = SaveFile(casteCertUpload, applicationDir, applicationId);

                    // Update with actual file paths
                    string updateQuery = @"
                        UPDATE Applications 
                        SET PhotoPath = @PhotoPath, IdProofPath = @IdProofPath, MarksheetPath = @MarksheetPath, 
                            IncomePath = @IncomePath, BankPassbookPath = @BankPassbookPath, CasteCertPath = @CasteCertPath 
                        WHERE ApplicationID = @ApplicationID";
                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        updateCmd.Parameters.AddWithValue("@PhotoPath", photoPath);
                        updateCmd.Parameters.AddWithValue("@IdProofPath", idProofPath);
                        updateCmd.Parameters.AddWithValue("@MarksheetPath", marksheetPath);
                        updateCmd.Parameters.AddWithValue("@IncomePath", incomePath);
                        updateCmd.Parameters.AddWithValue("@BankPassbookPath", bankPassbookPath);
                        updateCmd.Parameters.AddWithValue("@CasteCertPath", casteCertPath);
                        updateCmd.Parameters.AddWithValue("@ApplicationID", applicationId);
                        updateCmd.ExecuteNonQuery();
                    }

                    lblMessage.Text = "Application submitted successfully!";
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Application submitted successfully!');", true);
                    Response.Redirect("ApplicantDashboard.aspx");
                }
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
            lblMessage.ForeColor = System.Drawing.Color.Red;
        }
    }

    private string SaveFile(System.Web.UI.WebControls.FileUpload fileUpload, string uploadDir, int applicationId)
    {
        if (fileUpload.HasFile)
        {
            string fileName = Path.GetFileName(fileUpload.FileName);
            string extension = Path.GetExtension(fileName).ToLower();
            string[] validExtensions = { ".pdf", ".jpg" };
            if (Array.IndexOf(validExtensions, extension) == -1)
            {
                throw new Exception("Invalid file type. Please upload only PDF or JPG files.");
            }

            if (fileUpload.PostedFile.ContentLength > 5 * 1024 * 1024) // 5MB in bytes
            {
                throw new Exception("File size must not exceed 5MB.");
            }

            string filePath = Path.Combine(uploadDir, fileName);
            fileUpload.SaveAs(filePath);
            return String.Format("~/Uploads/{0}/{1}", applicationId, fileName);
        }
        throw new Exception("File upload failed."); // Shouldn’t reach here due to prior validation
    }

    private bool IsApplicationSubmissionEnabled()
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT ApplicationSubmissionEnabled FROM Settings WHERE SettingID = 1";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                object result = cmd.ExecuteScalar();
                if (result != null)
                {
                    return (bool)result;
                }
                return true; // Default to enabled if no setting exists
            }
        }
    }
}