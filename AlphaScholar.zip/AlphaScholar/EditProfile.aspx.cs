﻿using System;
using System.Configuration;
using System.Data.SqlClient;

public partial class EditProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ApplicantEmail"] == null)
        {
            lblError.Text = "Please log in to edit your profile.";
            lblError.Visible = true;
            Response.Redirect("Home.aspx");
            return;
        }

        if (!IsPostBack)
        {
            LoadApplicantDetails();
        }
    }

    private void LoadApplicantDetails()
    {
        string applicantEmail = Session["ApplicantEmail"] as string;
        if (string.IsNullOrEmpty(applicantEmail))
        {
            lblError.Text = "Please log in to edit your profile.";
            lblError.Visible = true;
            Response.Redirect("Home.aspx");
            return;
        }

        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT FullName, Email, Phone, Gender FROM Applicants WHERE Email = @Email";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Email", applicantEmail);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtFullName.Text = reader["FullName"].ToString();
                    txtEmail.Text = reader["Email"].ToString();
                    txtPhone.Text = reader["Phone"].ToString();
                    ddlGender.SelectedValue = reader["Gender"].ToString();
                }
            }
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        string applicantEmail = Session["ApplicantEmail"] as string;
        if (string.IsNullOrEmpty(applicantEmail))
        {
            lblError.Text = "Please log in to edit your profile.";
            lblError.Visible = true;
            Response.Redirect("Home.aspx");
            return;
        }

        string fullName = txtFullName.Text.Trim();
        string phone = txtPhone.Text.Trim();
        string gender = ddlGender.SelectedValue;

        // Phone number validation
        if (!System.Text.RegularExpressions.Regex.IsMatch(phone, @"^\d{10}$"))
        {
            lblError.Text = "Phone number must be a 10-digit number.";
            lblError.Visible = true;
            return;
        }

        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "UPDATE Applicants SET FullName=@FullName, Phone=@Phone, Gender=@Gender WHERE Email=@Email";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@FullName", fullName);
                cmd.Parameters.AddWithValue("@Phone", phone);
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@Email", applicantEmail);
                cmd.ExecuteNonQuery();
            }
        }

        lblMessage.Text = "Profile updated successfully!";
        Response.Redirect("ApplicantDashboard.aspx");
    }
}