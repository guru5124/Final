﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminDashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["AdminEmail"] == null)
        {
            Response.Redirect("AdminLogin.aspx");
            return;
        }

        if (!IsPostBack)
        {
            lnkApplications_Click(null, null); // Default to Pending Applications tab
            UpdateToggleButtonState(); // Set initial toggle button state
            LoadAdminName(); // Load admin name on initial load
        }
    }

    private void LoadAdminName()
    {
        string adminEmail = Session["AdminEmail"] as string;
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT Username FROM Admin WHERE Email = @Email";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Email", adminEmail);
                object result = cmd.ExecuteScalar();
                if (result != null)
                {
                    lblAdminName.Text = result.ToString();
                }
                else
                {
                    lblAdminName.Text = "Unknown Admin";
                }
            }
        }
    }

    // Tab Navigation
    protected void lnkApplications_Click(object sender, EventArgs e)
    {
        mvAdminDashboard.ActiveViewIndex = 0;
        SetActiveTab(lnkApplications);
        LoadApplications();
    }

    protected void lnkUsers_Click(object sender, EventArgs e)
    {
        mvAdminDashboard.ActiveViewIndex = 1;
        SetActiveTab(lnkUsers);
        LoadUsers();
    }

    protected void lnkApproved_Click(object sender, EventArgs e)
    {
        mvAdminDashboard.ActiveViewIndex = 2;
        SetActiveTab(lnkApproved);
        LoadApprovedApplications();
    }

    protected void lnkRejected_Click(object sender, EventArgs e)
    {
        mvAdminDashboard.ActiveViewIndex = 3;
        SetActiveTab(lnkRejected);
        LoadRejectedApplications();
    }

    protected void lnkReports_Click(object sender, EventArgs e)
    {
        mvAdminDashboard.ActiveViewIndex = 4;
        SetActiveTab(lnkReports);
        LoadReports();
    }

    protected void lnkSettings_Click(object sender, EventArgs e)
    {
        mvAdminDashboard.ActiveViewIndex = 5;
        SetActiveTab(lnkSettings);
        LoadAdminSettings();
    }

    private void SetActiveTab(LinkButton activeTab)
    {
        lnkApplications.CssClass = lnkApplications == activeTab ? "active" : "";
        lnkUsers.CssClass = lnkUsers == activeTab ? "active" : "";
        lnkApproved.CssClass = lnkApproved == activeTab ? "active" : "";
        lnkRejected.CssClass = lnkRejected == activeTab ? "active" : "";
        lnkReports.CssClass = lnkReports == activeTab ? "active" : "";
        lnkSettings.CssClass = lnkSettings == activeTab ? "active" : "";
    }

    // Pending Applications Tab
    private void LoadApplications()
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT ApplicationID, FullName, SubmissionDate, Status FROM Applications WHERE Status = 'Pending'";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                gvApplications.DataSource = dt;
                gvApplications.DataBind();
            }
        }
    }

    protected void gvApplications_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvApplications.PageIndex = e.NewPageIndex;
        LoadApplications();
    }

    protected void gvApplications_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int applicationId = Convert.ToInt32(e.CommandArgument);
        GridViewRow row = ((Button)e.CommandSource).NamingContainer as GridViewRow;
        TextBox txtRemark = row.FindControl("txtRemark") as TextBox;

        if (e.CommandName == "View")
        {
            ViewApplication(applicationId);
        }
        else if (e.CommandName == "Approve")
        {
            UpdateApplicationStatus(applicationId, "Approved", "");
            LoadApplications();
        }
        else if (e.CommandName == "Reject")
        {
            string remark = txtRemark != null ? txtRemark.Text.Trim() : "";
            UpdateApplicationStatus(applicationId, "Rejected", remark);
            LoadApplications();
        }
    }

    // Applicants Tab
    private void LoadUsers()
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT ApplicantID, FullName, Email FROM Applicants";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                gvUsers.DataSource = dt;
                gvUsers.DataBind();
            }
        }
    }

    protected void gvUsers_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvUsers.PageIndex = e.NewPageIndex;
        LoadUsers();
    }

    protected void gvUsers_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int applicantId = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "View")
        {
            ViewUser(applicantId);
        }
        else if (e.CommandName == "Delete")
        {
            DeleteUser(applicantId);
            LoadUsers();
        }
    }

    // Approved Applications Tab
    private void LoadApprovedApplications()
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT ApplicationID, FullName, SubmissionDate, Status FROM Applications WHERE Status = 'Approved'";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                gvApproved.DataSource = dt;
                gvApproved.DataBind();
            }
        }
    }

    protected void gvApproved_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvApproved.PageIndex = e.NewPageIndex;
        LoadApprovedApplications();
    }

    protected void gvApproved_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int applicationId = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "View")
        {
            ViewApplication(applicationId);
        }
        else if (e.CommandName == "Delete")
        {
            DeleteApplication(applicationId);
            LoadApprovedApplications();
        }
        else if (e.CommandName == "Pending")
        {
            UpdateApplicationStatus(applicationId, "Pending", "");
            LoadApprovedApplications();
        }
    }

    // Rejected Applications Tab
    private void LoadRejectedApplications()
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT ApplicationID, FullName, SubmissionDate, Status FROM Applications WHERE Status = 'Rejected'";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                gvRejected.DataSource = dt;
                gvRejected.DataBind();
            }
        }
    }

    protected void gvRejected_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvRejected.PageIndex = e.NewPageIndex;
        LoadRejectedApplications();
    }

    protected void gvRejected_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int applicationId = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "View")
        {
            ViewApplication(applicationId);
        }
        else if (e.CommandName == "Delete")
        {
            DeleteApplication(applicationId);
            LoadRejectedApplications();
        }
        else if (e.CommandName == "Pending")
        {
            UpdateApplicationStatus(applicationId, "Pending", "");
            LoadRejectedApplications();
        }
    }

    // Reports Tab
    private void LoadReports()
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();

            // Load summary counts
            string summaryQuery = @"
                SELECT 
                    SUM(CASE WHEN Status = 'Pending' THEN 1 ELSE 0 END) AS PendingCount,
                    SUM(CASE WHEN Status = 'Approved' THEN 1 ELSE 0 END) AS ApprovedCount,
                    SUM(CASE WHEN Status = 'Rejected' THEN 1 ELSE 0 END) AS RejectedCount,
                    COUNT(*) AS TotalCount
                FROM Applications";
            if (!string.IsNullOrEmpty(txtFromDate.Text) || !string.IsNullOrEmpty(txtToDate.Text))
            {
                summaryQuery += " WHERE 1=1";
                if (!string.IsNullOrEmpty(txtFromDate.Text))
                    summaryQuery += " AND SubmissionDate >= @FromDate";
                if (!string.IsNullOrEmpty(txtToDate.Text))
                    summaryQuery += " AND SubmissionDate <= @ToDate";
            }
            using (SqlCommand cmd = new SqlCommand(summaryQuery, conn))
            {
                if (!string.IsNullOrEmpty(txtFromDate.Text))
                    cmd.Parameters.AddWithValue("@FromDate", DateTime.Parse(txtFromDate.Text));
                if (!string.IsNullOrEmpty(txtToDate.Text))
                    cmd.Parameters.AddWithValue("@ToDate", DateTime.Parse(txtToDate.Text).AddDays(1).AddTicks(-1)); // End of day
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    lblPendingCount.Text = reader["PendingCount"].ToString();
                    lblApprovedCount.Text = reader["ApprovedCount"].ToString();
                    lblRejectedCount.Text = reader["RejectedCount"].ToString();
                    lblTotalCount.Text = reader["TotalCount"].ToString();
                }
                reader.Close();
            }

            // Load grid data with filters
            string query = "SELECT ApplicationID, FullName, SubmissionDate, Status FROM Applications WHERE 1=1";
            if (!string.IsNullOrEmpty(ddlStatusFilter.SelectedValue))
                query += " AND Status = @Status";
            if (!string.IsNullOrEmpty(txtFromDate.Text))
                query += " AND SubmissionDate >= @FromDate";
            if (!string.IsNullOrEmpty(txtToDate.Text))
                query += " AND SubmissionDate <= @ToDate";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                if (!string.IsNullOrEmpty(ddlStatusFilter.SelectedValue))
                    cmd.Parameters.AddWithValue("@Status", ddlStatusFilter.SelectedValue);
                if (!string.IsNullOrEmpty(txtFromDate.Text))
                    cmd.Parameters.AddWithValue("@FromDate", DateTime.Parse(txtFromDate.Text));
                if (!string.IsNullOrEmpty(txtToDate.Text))
                    cmd.Parameters.AddWithValue("@ToDate", DateTime.Parse(txtToDate.Text).AddDays(1).AddTicks(-1)); // End of day
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                gvReports.DataSource = dt;
                gvReports.DataBind();

                // Store data in ViewState for export
                ViewState["ReportData"] = dt;
            }
        }
    }

    protected void gvReports_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvReports.PageIndex = e.NewPageIndex;
        LoadReports();
    }

    protected void gvReports_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "View")
        {
            int applicationId = Convert.ToInt32(e.CommandArgument);
            ViewApplication(applicationId);
        }
    }

    protected void ddlStatusFilter_SelectedIndexChanged(object sender, EventArgs e)
    {
        LoadReports();
    }

    protected void btnFilter_Click(object sender, EventArgs e)
    {
        LoadReports();
    }

    protected void btnExportCSV_Click(object sender, EventArgs e)
    {
        DataTable dt = ViewState["ReportData"] as DataTable;
        if (dt != null && dt.Rows.Count > 0)
        {
            StringBuilder sb = new StringBuilder();
            string[] columnNames = new string[dt.Columns.Count];
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                columnNames[i] = dt.Columns[i].ColumnName;
            }
            sb.AppendLine(string.Join(",", columnNames));

            foreach (DataRow row in dt.Rows)
            {
                string[] fields = new string[row.ItemArray.Length];
                for (int i = 0; i < row.ItemArray.Length; i++)
                {
                    fields[i] = "\"" + row[i].ToString().Replace("\"", "\"\"") + "\"";
                }
                sb.AppendLine(string.Join(",", fields));
            }

            Response.Clear();
            Response.ContentType = "text/csv";
            Response.AddHeader("Content-Disposition", "attachment;filename=ApplicationReport_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv");
            Response.Write(sb.ToString());
            Response.End();
        }
        else
        {
            lblError.Text = "No data available to export.";
            lblError.Visible = true;
        }
    }

    protected void btnExportPDF_Click(object sender, EventArgs e)
    {
        DataTable dt = ViewState["ReportData"] as DataTable;
        if (dt != null && dt.Rows.Count > 0)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<html><head><title>Application Report</title>");
            sb.Append("<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ddd; padding: 8px; text-align: left; } th { background-color: #2d3e50; color: white; }</style>");
            sb.Append("</head><body>");
            sb.Append("<h2>Application Report</h2>");
            sb.Append("<p>Generated on: " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + "</p>");
            if (!string.IsNullOrEmpty(txtFromDate.Text))
                sb.Append("<p>From: " + txtFromDate.Text + "</p>");
            if (!string.IsNullOrEmpty(txtToDate.Text))
                sb.Append("<p>To: " + txtToDate.Text + "</p>");
            if (!string.IsNullOrEmpty(ddlStatusFilter.SelectedValue))
                sb.Append("<p>Status: " + ddlStatusFilter.SelectedValue + "</p>");
            sb.Append("<table><tr>");
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                sb.Append("<th>" + dt.Columns[i].ColumnName + "</th>");
            }
            sb.Append("</tr>");
            foreach (DataRow row in dt.Rows)
            {
                sb.Append("<tr>");
                for (int i = 0; i < row.ItemArray.Length; i++)
                {
                    sb.Append("<td>" + row[i].ToString() + "</td>");
                }
                sb.Append("</tr>");
            }
            sb.Append("</table></body></html>");

            Response.Clear();
            Response.ContentType = "application/pdf";
            Response.AddHeader("Content-Disposition", "attachment;filename=ApplicationReport_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".pdf");
            Response.Write(sb.ToString());
            Response.End();
        }
        else
        {
            lblError.Text = "No data available to export.";
            lblError.Visible = true;
        }
    }

    // Common Methods
    private void UpdateApplicationStatus(int applicationId, string status, string remark)
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "UPDATE Applications SET Status = @Status, Remark = @Remark WHERE ApplicationID = @ApplicationID";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Status", status);
                cmd.Parameters.AddWithValue("@Remark", string.IsNullOrEmpty(remark) ? (object)DBNull.Value : remark);
                cmd.Parameters.AddWithValue("@ApplicationID", applicationId);
                cmd.ExecuteNonQuery();
            }
        }
    }

    private void DeleteApplication(int applicationId)
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "DELETE FROM Applications WHERE ApplicationID = @ApplicationID";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@ApplicationID", applicationId);
                cmd.ExecuteNonQuery();
            }
        }
    }

    private void DeleteUser(int applicantId)
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "DELETE FROM Applicants WHERE ApplicantID = @ApplicantID";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@ApplicantID", applicantId);
                cmd.ExecuteNonQuery();
            }
        }
    }

    private void ViewUser(int applicantId)
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        string fullName = "", email = "", phone = "", gender = "";
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT FullName, Email, Phone, Gender FROM Applicants WHERE ApplicantID = @ApplicantID";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@ApplicantID", applicantId);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    fullName = reader["FullName"].ToString();
                    email = reader["Email"].ToString();
                    phone = reader["Phone"].ToString();
                    gender = reader["Gender"].ToString();
                }
            }
        }

        string htmlContent = "<html>" +
            "<head>" +
            "<title>Applicant Details</title>" +
            "<style>" +
            "body { font-family: Arial, sans-serif; padding: 20px; background-color: #f9f9f9; }" +
            ".container { width: 80%; margin: auto; padding: 20px; text-align: center; }" +
            ".application-card { background: #fff; padding: 15px; border-radius: 8px; box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1); max-width: 400px; margin: 0 auto; }" +
            ".application-card p { margin: 5px 0; text-align: left; }" +
            ".btn { padding: 10px 20px; border-radius: 5px; font-size: 14px; font-weight: bold; border: none; cursor: pointer; transition: 0.3s; text-decoration: none; background: #3498db; color: white; display: inline-block; margin-top: 20px; }" +
            ".btn:hover { background: #2980b9; }" +
            "</style>" +
            "</head>" +
            "<body>" +
            "<div class='container'>" +
            "<div class='application-card'>" +
            "<p><strong>Full Name:</strong> " + fullName + "</p>" +
            "<p><strong>Email:</strong> " + email + "</p>" +
            "<p><strong>Phone:</strong> " + phone + "</p>" +
            "<p><strong>Gender:</strong> " + gender + "</p>" +
            "<a href='AdminDashboard.aspx' class='btn'>Back to Dashboard</a>" +
            "</div>" +
            "</div>" +
            "</body>" +
            "</html>";

        Response.Clear();
        Response.ContentType = "text/html";
        Response.Write(htmlContent);
        Response.Flush();
        Response.SuppressContent = true;
        HttpContext.Current.ApplicationInstance.CompleteRequest();
    }

    protected string GetStatusColor(string status)
    {
        switch (status.ToLower())
        {
            case "pending":
                return "#f39c12"; // Orange
            case "approved":
                return "#2ecc71"; // Green
            case "rejected":
                return "#e74c3c"; // Red
            default:
                return "#95a5a6"; // Grey
        }
    }

    private void ViewApplication(int applicationID)
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        string fullName = "", dob = "", email = "", phone = "", gender = "", address = "", motherName = "", category = "",
               maritalStatus = "", parentOccupation = "", annualFamilyIncome = "", isOrphan = "", courseYear = "",
               courseName = "", courseType = "", previousEducation = "", examFees = "", admissionFees = "",
               presentInstitute = "", presentCourseYear = "", presentCourseType = "", percentage = "",
               bankName = "", accountNumber = "", ifscCode = "", branchName = "", pincode = "",
               taluka = "", district = "", state = "", currentAddress = "", status = "", submissionDate = "",
               remark = "", photoPath = "", idProofPath = "", marksheetPath = "", incomePath = "",
               bankPassbookPath = "", casteCertPath = "";

        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT FullName, DOB, Email, Phone, Gender, Address, MotherName, Category, MaritalStatus, ParentOccupation, " +
                           "AnnualFamilyIncome, IsOrphan, CourseYear, CourseName, CourseType, PreviousEducation, ExamFees, " +
                           "AdmissionFees, PresentInstitute, PresentCourseYear, PresentCourseType, Percentage, BankName, " +
                           "AccountNumber, IFSCCode, BranchName, Pincode, Taluka, District, State, CurrentAddress, " +
                           "SubmissionDate, Status, Remark, PhotoPath, IdProofPath, MarksheetPath, IncomePath, " +
                           "BankPassbookPath, CasteCertPath " +
                           "FROM Applications WHERE ApplicationID = @ApplicationID";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@ApplicationID", applicationID);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    fullName = reader["FullName"].ToString();
                    dob = Convert.ToDateTime(reader["DOB"]).ToString("dd/MM/yyyy");
                    email = reader["Email"].ToString();
                    phone = reader["Phone"].ToString();
                    gender = reader["Gender"].ToString();
                    address = reader["Address"].ToString();
                    motherName = reader["MotherName"].ToString();
                    category = reader["Category"].ToString();
                    maritalStatus = reader["MaritalStatus"].ToString();
                    parentOccupation = reader["ParentOccupation"].ToString();
                    annualFamilyIncome = reader["AnnualFamilyIncome"] != DBNull.Value ? reader["AnnualFamilyIncome"].ToString() : "Not Provided";
                    isOrphan = Convert.ToBoolean(reader["IsOrphan"]) ? "Yes" : "No";
                    courseYear = reader["CourseYear"].ToString();
                    courseName = reader["CourseName"].ToString();
                    courseType = reader["CourseType"].ToString();
                    previousEducation = reader["PreviousEducation"] != DBNull.Value ? reader["PreviousEducation"].ToString() : "Not Provided";
                    examFees = reader["ExamFees"] != DBNull.Value ? reader["ExamFees"].ToString() : "Not Provided";
                    admissionFees = reader["AdmissionFees"] != DBNull.Value ? reader["AdmissionFees"].ToString() : "Not Provided";
                    presentInstitute = reader["PresentInstitute"].ToString();
                    presentCourseYear = reader["PresentCourseYear"].ToString();
                    presentCourseType = reader["PresentCourseType"].ToString();
                    percentage = reader["Percentage"].ToString();
                    bankName = reader["BankName"].ToString();
                    accountNumber = reader["AccountNumber"].ToString();
                    ifscCode = reader["IFSCCode"].ToString();
                    branchName = reader["BranchName"].ToString();
                    pincode = reader["Pincode"].ToString();
                    taluka = reader["Taluka"].ToString();
                    district = reader["District"].ToString();
                    state = reader["State"].ToString();
                    currentAddress = reader["CurrentAddress"].ToString();
                    submissionDate = Convert.ToDateTime(reader["SubmissionDate"]).ToString("dd/MM/yyyy HH:mm:ss");
                    status = reader["Status"].ToString();
                    remark = reader["Remark"] != DBNull.Value ? reader["Remark"].ToString() : "Not Provided";
                    photoPath = reader["PhotoPath"] != DBNull.Value ? reader["PhotoPath"].ToString() : "";
                    idProofPath = reader["IdProofPath"] != DBNull.Value ? reader["IdProofPath"].ToString() : "";
                    marksheetPath = reader["MarksheetPath"] != DBNull.Value ? reader["MarksheetPath"].ToString() : "";
                    incomePath = reader["IncomePath"] != DBNull.Value ? reader["IncomePath"].ToString() : "";
                    bankPassbookPath = reader["BankPassbookPath"] != DBNull.Value ? reader["BankPassbookPath"].ToString() : "";
                    casteCertPath = reader["CasteCertPath"] != DBNull.Value ? reader["CasteCertPath"].ToString() : "";
                }
            }
        }

        string htmlContent = "<html>" +
            "<head>" +
            "<title>Application Details</title>" +
            "<style>" +
            "body { font-family: Arial, sans-serif; padding: 20px; background-color: #f9f9f9; }" +
            ".container { width: 80%; margin: auto; padding: 20px; text-align: center; }" +
            "table { width: 100%; max-width: 600px; margin: 20px auto; border-collapse: collapse; background: #fff; box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1); }" +
            "th, td { padding: 10px; text-align: left; border: 1px solid #ddd; }" +
            "th { background: #2d3e50; color: white; }" +
            ".status-label { padding: 5px 10px; border-radius: 5px; color: black; font-weight: bold; text-transform: uppercase; display: inline-block; }" +
            "a { color: #3498db; text-decoration: none; }" +
            "a:hover { text-decoration: underline; }" +
            ".btn { padding: 10px 20px; border-radius: 5px; font-size: 14px; font-weight: bold; border: none; cursor: pointer; transition: 0.3s; text-decoration: none; background: #3498db; color: white; display: inline-block; margin-top: 20px; }" +
            ".btn:hover { background: #2980b9; }" +
            "</style>" +
            "</head>" +
            "<body>" +
            "<div class='container'>" +
            "<table>" +
            "<tr><th>Field</th><th>Value</th></tr>" +
            "<tr><td>Application ID</td><td>" + applicationID + "</td></tr>" +
            "<tr><td>Full Name</td><td>" + fullName + "</td></tr>" +
            "<tr><td>Date of Birth</td><td>" + dob + "</td></tr>" +
            "<tr><td>Email</td><td>" + email + "</td></tr>" +
            "<tr><td>Phone</td><td>" + phone + "</td></tr>" +
            "<tr><td>Gender</td><td>" + gender + "</td></tr>" +
            "<tr><td>Address</td><td>" + address + "</td></tr>" +
            "<tr><td>Mother's Name</td><td>" + motherName + "</td></tr>" +
            "<tr><td>Category</td><td>" + category + "</td></tr>" +
            "<tr><td>Marital Status</td><td>" + maritalStatus + "</td></tr>" +
            "<tr><td>Parent Occupation</td><td>" + parentOccupation + "</td></tr>" +
            "<tr><td>Annual Family Income</td><td>" + annualFamilyIncome + "</td></tr>" +
            "<tr><td>Is Orphan?</td><td>" + isOrphan + "</td></tr>" +
            "<tr><td>Course Year</td><td>" + courseYear + "</td></tr>" +
            "<tr><td>Course Name</td><td>" + courseName + "</td></tr>" +
            "<tr><td>Course Type</td><td>" + courseType + "</td></tr>" +
            "<tr><td>Previous Education</td><td>" + previousEducation + "</td></tr>" +
            "<tr><td>Exam Fees</td><td>" + examFees + "</td></tr>" +
            "<tr><td>Admission Fees</td><td>" + admissionFees + "</td></tr>" +
            "<tr><td>Present Institute</td><td>" + presentInstitute + "</td></tr>" +
            "<tr><td>Present Course Year</td><td>" + presentCourseYear + "</td></tr>" +
            "<tr><td>Present Course Type</td><td>" + presentCourseType + "</td></tr>" +
            "<tr><td>Percentage</td><td>" + percentage + "</td></tr>" +
            "<tr><td>Bank Name</td><td>" + bankName + "</td></tr>" +
            "<tr><td>Account Number</td><td>" + accountNumber + "</td></tr>" +
            "<tr><td>IFSC Code</td><td>" + ifscCode + "</td></tr>" +
            "<tr><td>Branch Name</td><td>" + branchName + "</td></tr>" +
            "<tr><td>Pincode</td><td>" + pincode + "</td></tr>" +
            "<tr><td>Taluka</td><td>" + taluka + "</td></tr>" +
            "<tr><td>District</td><td>" + district + "</td></tr>" +
            "<tr><td>State</td><td>" + state + "</td></tr>" +
            "<tr><td>Current Address</td><td>" + currentAddress + "</td></tr>" +
            "<tr><td>Submission Date</td><td>" + submissionDate + "</td></tr>" +
            "<tr><td>Status</td><td><span class='status-label' style='background-color: " + GetStatusColor(status) + ";'>" + status + "</span></td></tr>" +
            "<tr><td>Remark</td><td>" + remark + "</td></tr>" +
            "<tr><td>Photo</td><td><a href='" + ResolveUrl(photoPath) + "' target='_blank'>View Photo</a></td></tr>" +
            "<tr><td>ID Proof</td><td><a href='" + ResolveUrl(idProofPath) + "' target='_blank'>View ID Proof</a></td></tr>" +
            "<tr><td>Marksheet</td><td><a href='" + ResolveUrl(marksheetPath) + "' target='_blank'>View Marksheet</a></td></tr>" +
            "<tr><td>Income Certificate</td><td><a href='" + ResolveUrl(incomePath) + "' target='_blank'>View Income Certificate</a></td></tr>" +
            "<tr><td>Bank Passbook</td><td><a href='" + ResolveUrl(bankPassbookPath) + "' target='_blank'>View Bank Passbook</a></td></tr>" +
            "<tr><td>Caste Certificate</td><td><a href='" + ResolveUrl(casteCertPath) + "' target='_blank'>View Caste Certificate</a></td></tr>" +
            "</table>" +
            "<a href='AdminDashboard.aspx' class='btn'>Back to Dashboard</a>" +
            "</div>" +
            "</body>" +
            "</html>";

        Response.Clear();
        Response.ContentType = "text/html";
        Response.Write(htmlContent);
        Response.Flush();
        Response.SuppressContent = true;
        HttpContext.Current.ApplicationInstance.CompleteRequest();
    }

    // Settings Tab
    private void LoadAdminSettings()
    {
        string adminEmail = Session["AdminEmail"] as string;
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT Username, Email, Phone FROM Admin WHERE Email = @Email";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Email", adminEmail);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtAdminUsername.Text = reader["Username"].ToString();
                    txtAdminEmail.Text = reader["Email"].ToString();
                    txtAdminPhone.Text = reader["Phone"].ToString();
                }
            }
        }
        UpdateToggleButtonState();
    }

    protected void btnUpdateAdmin_Click(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "UPDATE Admin SET Username = @Username, Phone = @Phone, Password = @Password WHERE Email = @Email";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", txtAdminUsername.Text.Trim());
                    cmd.Parameters.AddWithValue("@Phone", txtAdminPhone.Text.Trim());
                    cmd.Parameters.AddWithValue("@Password", txtAdminPassword.Text); // Should hash in production
                    cmd.Parameters.AddWithValue("@Email", Session["AdminEmail"].ToString());
                    cmd.ExecuteNonQuery();
                }
            }
            lblSettingsError.Text = "Credentials updated successfully!";
            lblSettingsError.ForeColor = System.Drawing.Color.Green;
            lblSettingsError.Visible = true;
            LoadAdminName();
        }
        catch (Exception ex)
        {
            lblSettingsError.Text = "Error: " + ex.Message;
            lblSettingsError.ForeColor = System.Drawing.Color.Red;
            lblSettingsError.Visible = true;
        }
    }

    protected void btnToggleApplications_Click(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "UPDATE Settings SET ApplicationSubmissionEnabled = CASE WHEN ApplicationSubmissionEnabled = 1 THEN 0 ELSE 1 END WHERE SettingID = 1";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected == 0) // If no row exists, insert one
                {
                    query = "INSERT INTO Settings (ApplicationSubmissionEnabled) VALUES (0)"; // No explicit SettingID
                    using (SqlCommand insertCmd = new SqlCommand(query, conn))
                    {
                        insertCmd.ExecuteNonQuery();
                    }
                }
            }
        }
        UpdateToggleButtonState();
    }

    private void UpdateToggleButtonState()
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        bool isEnabled = true; // Default to enabled if no data exists
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT ApplicationSubmissionEnabled FROM Settings WHERE SettingID = 1";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                object result = cmd.ExecuteScalar();
                if (result != null)
                {
                    isEnabled = (bool)result;
                }
                else
                {
                    query = "INSERT INTO Settings (ApplicationSubmissionEnabled) VALUES (1)"; // No explicit SettingID
                    using (SqlCommand insertCmd = new SqlCommand(query, conn))
                    {
                        insertCmd.ExecuteNonQuery();
                    }
                }
            }
        }
        btnToggleApplications.Text = isEnabled ? "Disable Application Submission" : "Enable Application Submission";
        btnToggleApplications.CssClass = isEnabled ? "btn btn-toggle-enabled" : "btn btn-toggle-disabled";
    }

    protected bool IsApplicationSubmissionEnabled()
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT ApplicationSubmissionEnabled FROM Settings WHERE SettingID = 1";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                object result = cmd.ExecuteScalar();
                if (result != null)
                {
                    return (bool)result;
                }
                return true; // Default to enabled if no setting exists
            }
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("AdminLogin.aspx");
    }
}