﻿using System;
using System.Configuration;
using System.Data.SqlClient;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Restore the last used form (login or register)
            if (Session["FormState"] != null && Session["FormState"].ToString() == "Register")
            {
                ShowRegisterForm();
            }
            else
            {
                ShowLoginForm();
            }
        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string username = txtLoginUsername.Text.Trim();
        string password = txtLoginPassword.Text.Trim();

        if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
        {
            lblLoginError.Text = "Username and Password are required!";
            lblLoginError.Visible = true;
            Session["FormState"] = "Login"; // Keep login form visible
            ShowLoginForm();
            return;
        }

        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;

        using (SqlConnection con = new SqlConnection(connStr))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT Email FROM Applicants WHERE Username=@Username AND Password=@Password", con);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Password", password); // Plain text as per instruction

            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                Session["Username"] = username;
                Session["ApplicantEmail"] = reader["Email"].ToString();
                Response.Redirect("ApplicantDashboard.aspx");
            }
            else
            {
                lblLoginError.Text = "Invalid username or password!";
                lblLoginError.Visible = true;
                Session["FormState"] = "Login";
                ShowLoginForm();
            }
        }
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        string fullName = txtRegisterFullName.Text.Trim();
        string phone = txtRegisterPhone.Text.Trim();
        string gender = ddlRegisterGender.SelectedValue;
        string username = txtRegisterUsername.Text.Trim();
        string password = txtRegisterPassword.Text.Trim();
        string email = txtRegisterEmail.Text.Trim();

        if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(phone) || string.IsNullOrEmpty(gender) ||
            string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(email))
        {
            lblRegisterError.Text = "All fields are required!";
            lblRegisterError.Visible = true;
            Session["FormState"] = "Register";
            ShowRegisterForm();
            return;
        }

        // Phone number validation: Must be 10 digits
        if (!System.Text.RegularExpressions.Regex.IsMatch(phone, @"^\d{10}$"))
        {
            lblRegisterError.Text = "Phone number must be a 10-digit number!";
            lblRegisterError.Visible = true;
            Session["FormState"] = "Register";
            ShowRegisterForm();
            return;
        }

        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;

        using (SqlConnection con = new SqlConnection(connStr))
        {
            con.Open();

            // Check for duplicate username
            SqlCommand checkUser = new SqlCommand("SELECT COUNT(*) FROM Applicants WHERE Username=@Username", con);
            checkUser.Parameters.AddWithValue("@Username", username);
            int userExists = (int)checkUser.ExecuteScalar();
            if (userExists > 0)
            {
                lblRegisterError.Text = "Username already exists!";
                lblRegisterError.Visible = true;
                Session["FormState"] = "Register";
                ShowRegisterForm();
                return;
            }

            // Check for duplicate email
            SqlCommand checkEmail = new SqlCommand("SELECT COUNT(*) FROM Applicants WHERE Email=@Email", con);
            checkEmail.Parameters.AddWithValue("@Email", email);
            int emailExists = (int)checkEmail.ExecuteScalar();
            if (emailExists > 0)
            {
                lblRegisterError.Text = "Email already exists!";
                lblRegisterError.Visible = true;
                Session["FormState"] = "Register";
                ShowRegisterForm();
                return;
            }

            // Insert new applicant
            SqlCommand cmd = new SqlCommand(@"INSERT INTO Applicants (FullName, Phone, Gender, Username, Password, Email) 
                                          VALUES (@FullName, @Phone, @Gender, @Username, @Password, @Email)", con);
            cmd.Parameters.AddWithValue("@FullName", fullName);
            cmd.Parameters.AddWithValue("@Phone", phone);
            cmd.Parameters.AddWithValue("@Gender", gender);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Password", password); // Plain text as per instruction
            cmd.Parameters.AddWithValue("@Email", email);

            cmd.ExecuteNonQuery();
            Response.Redirect("Home.aspx");
        }
    }

    private void ShowLoginForm()
    {
        loginForm.Style["display"] = "block";
        registerForm.Style["display"] = "none";
    }

    private void ShowRegisterForm()
    {
        loginForm.Style["display"] = "none";
        registerForm.Style["display"] = "block";
    }
}