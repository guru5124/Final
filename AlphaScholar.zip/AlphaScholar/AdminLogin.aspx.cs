﻿using System;
using System.Configuration;
using System.Data.SqlClient;

public partial class AdminLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Restore the last used form (login or register)
            if (Session["AdminFormState"] != null && Session["AdminFormState"].ToString() == "Register")
            {
                ShowRegisterForm();
            }
            else
            {
                ShowLoginForm();
            }
        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string username = txtAdminLoginUsername.Text.Trim();
        string password = txtAdminLoginPassword.Text.Trim();

        if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
        {
            lblAdminLoginError.Text = "Username and Password are required!";
            lblAdminLoginError.Visible = true;
            Session["AdminFormState"] = "Login";
            ShowLoginForm();
            return;
        }

        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;

        using (SqlConnection con = new SqlConnection(connStr))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT Email FROM Admin WHERE Username=@Username AND Password=@Password", con);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Password", password); // Plain text as per your preference

            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                Session["AdminEmail"] = reader["Email"].ToString();
                Response.Redirect("AdminDashboard.aspx");
            }
            else
            {
                lblAdminLoginError.Text = "Invalid admin username or password!";
                lblAdminLoginError.Visible = true;
                Session["AdminFormState"] = "Login";
                ShowLoginForm();
            }
        }
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        string username = txtAdminRegisterUsername.Text.Trim();
        string password = txtAdminRegisterPassword.Text.Trim();
        string email = txtAdminRegisterEmail.Text.Trim();
        string phone = txtAdminRegisterPhone.Text.Trim();

        if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(email))
        {
            lblAdminRegisterError.Text = "Username, Password, and Email are required!";
            lblAdminRegisterError.Visible = true;
            Session["AdminFormState"] = "Register";
            ShowRegisterForm();
            return;
        }

        // Optional phone validation: if provided, must be 10 digits
        if (!string.IsNullOrEmpty(phone) && !System.Text.RegularExpressions.Regex.IsMatch(phone, @"^\d{10}$"))
        {
            lblAdminRegisterError.Text = "Phone number must be a 10-digit number if provided!";
            lblAdminRegisterError.Visible = true;
            Session["AdminFormState"] = "Register";
            ShowRegisterForm();
            return;
        }

        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;

        using (SqlConnection con = new SqlConnection(connStr))
        {
            con.Open();

            // Check for duplicate username
            SqlCommand checkUser = new SqlCommand("SELECT COUNT(*) FROM Admin WHERE Username=@Username", con);
            checkUser.Parameters.AddWithValue("@Username", username);
            int userExists = (int)checkUser.ExecuteScalar();
            if (userExists > 0)
            {
                lblAdminRegisterError.Text = "Username already exists!";
                lblAdminRegisterError.Visible = true;
                Session["AdminFormState"] = "Register";
                ShowRegisterForm();
                return;
            }

            // Check for duplicate email
            SqlCommand checkEmail = new SqlCommand("SELECT COUNT(*) FROM Admin WHERE Email=@Email", con);
            checkEmail.Parameters.AddWithValue("@Email", email);
            int emailExists = (int)checkEmail.ExecuteScalar();
            if (emailExists > 0)
            {
                lblAdminRegisterError.Text = "Email already exists!";
                lblAdminRegisterError.Visible = true;
                Session["AdminFormState"] = "Register";
                ShowRegisterForm();
                return;
            }

            // Insert new admin
            SqlCommand cmd = new SqlCommand(@"INSERT INTO Admin (Username, Password, Email, Phone) 
                                          VALUES (@Username, @Password, @Email, @Phone)", con);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Password", password); // Plain text as per your preference
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@Phone", string.IsNullOrEmpty(phone) ? (object)DBNull.Value : phone);

            cmd.ExecuteNonQuery();
            Response.Redirect("AdminLogin.aspx");
        }
    }

    private void ShowLoginForm()
    {
        loginForm.Style["display"] = "block";
        registerForm.Style["display"] = "none";
    }

    private void ShowRegisterForm()
    {
        loginForm.Style["display"] = "none";
        registerForm.Style["display"] = "block";
    }
}