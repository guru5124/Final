﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Web.UI;

public partial class EditApplication : Page
{
    string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
    protected int ApplicationID;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ApplicantEmail"] == null)
        {
            Response.Redirect("Home.aspx");
            lblMessage.Text = "Please log in to edit an application.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            return;
        }

        // Fetch ApplicationID on every load to ensure it’s available
        if (Request.QueryString["ApplicationID"] != null)
        {
            try
            {
                ApplicationID = Convert.ToInt32(Request.QueryString["ApplicationID"]);
                ViewState["ApplicationID"] = ApplicationID; // Persist in ViewState
                System.Diagnostics.Debug.WriteLine("ApplicationID from QueryString: " + ApplicationID);
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error: Invalid ApplicationID in URL. " + ex.Message;
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }
        }
        else
        {
            lblMessage.Text = "Error: ApplicationID not provided in URL.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            Response.Redirect("ApplicantDashboard.aspx");
            return;
        }

        if (!IsPostBack)
        {
            if (!IsApplicationSubmissionEnabled())
            {
                btnUpdate.Enabled = false; // Assuming button ID is btnUpdate
                lblMessage.Text = "Application editing is currently disabled by the admin.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Visible = true;
            }
            else
            {
                LoadApplicationDetails(ApplicationID);
            }
        }
    }

    private void LoadApplicationDetails(int applicationID)
    {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT FullName, DOB, Email, Phone, Gender, Address, MotherName, Category, MaritalStatus, ParentOccupation, " +
                           "AnnualFamilyIncome, IsOrphan, CourseYear, CourseName, CourseType, PreviousEducation, ExamFees, " +
                           "AdmissionFees, PresentInstitute, PresentCourseYear, PresentCourseType, Percentage, BankName, " +
                           "AccountNumber, IFSCCode, BranchName, Pincode, Taluka, District, State, CurrentAddress, " +
                           "PhotoPath, IdProofPath, MarksheetPath, IncomePath, BankPassbookPath, CasteCertPath " +
                           "FROM Applications WHERE ApplicationID = @ApplicationID";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@ApplicationID", applicationID);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string fullName = reader["FullName"].ToString();
                    string[] names = fullName.Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    firstName.Text = names.Length > 0 ? names[0] : "";
                    middleName.Text = names.Length > 1 ? names[1] : "";
                    lastName.Text = names.Length > 2 ? names[2] : "";

                    dob.Text = Convert.ToDateTime(reader["DOB"]).ToString("yyyy-MM-dd");
                    email.Text = reader["Email"].ToString();
                    mobileNumber.Text = reader["Phone"].ToString();
                    gender.SelectedValue = reader["Gender"].ToString();
                    motherName.Text = reader["MotherName"].ToString();
                    category.SelectedValue = reader["Category"].ToString();
                    maritalStatus.SelectedValue = reader["MaritalStatus"].ToString();
                    parentOccupation.Text = reader["ParentOccupation"].ToString();
                    annualIncome.Text = reader["AnnualFamilyIncome"].ToString();
                    isOrphan.Checked = Convert.ToBoolean(reader["IsOrphan"]);
                    courseYear.Text = reader["CourseYear"].ToString();
                    courseName.Text = reader["CourseName"].ToString();
                    courseType.Text = reader["CourseType"].ToString();
                    previousEducation.Text = reader["PreviousEducation"].ToString();
                    examFees.Text = reader["ExamFees"].ToString();
                    admissionFees.Text = reader["AdmissionFees"].ToString();
                    presentInstitute.Text = reader["PresentInstitute"].ToString();
                    presentCourseYear.Text = reader["PresentCourseYear"].ToString();
                    presentCourseType.Text = reader["PresentCourseType"].ToString();
                    percentage.Text = reader["Percentage"].ToString();
                    bankName.Text = reader["BankName"].ToString();
                    accountNumber.Text = reader["AccountNumber"].ToString();
                    ifscCode.Text = reader["IFSCCode"].ToString();
                    branchName.Text = reader["BranchName"].ToString();
                    pincode.Text = reader["Pincode"].ToString();
                    address.Text = reader["Address"].ToString();
                    taluka.Text = reader["Taluka"].ToString();
                    district.Text = reader["District"].ToString();
                    state.Text = reader["State"].ToString();
                    currentAddress.Text = reader["CurrentAddress"].ToString();

                    ViewState["PhotoPath"] = reader["PhotoPath"] != DBNull.Value ? reader["PhotoPath"].ToString() : "";
                    ViewState["IdProofPath"] = reader["IdProofPath"] != DBNull.Value ? reader["IdProofPath"].ToString() : "";
                    ViewState["MarksheetPath"] = reader["MarksheetPath"] != DBNull.Value ? reader["MarksheetPath"].ToString() : "";
                    ViewState["IncomePath"] = reader["IncomePath"] != DBNull.Value ? reader["IncomePath"].ToString() : "";
                    ViewState["BankPassbookPath"] = reader["BankPassbookPath"] != DBNull.Value ? reader["BankPassbookPath"].ToString() : "";
                    ViewState["CasteCertPath"] = reader["CasteCertPath"] != DBNull.Value ? reader["CasteCertPath"].ToString() : "";
                }
                else
                {
                    lblMessage.Text = "Error: No application found with ApplicationID " + applicationID;
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    Response.Redirect("ApplicantDashboard.aspx");
                }
            }
        }
    }

    protected void UpdateApplication(object sender, EventArgs e)
    {
        if (!IsApplicationSubmissionEnabled())
        {
            lblMessage.Text = "Application editing is currently disabled by the admin.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            lblMessage.Visible = true;
            return;
        }

        string applicantEmail = Session["ApplicantEmail"] as string;
        if (string.IsNullOrEmpty(applicantEmail))
        {
            lblMessage.Text = "Please log in to edit an application.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            Response.Redirect("Home.aspx");
            return;
        }

        // Validate required fields
        if (string.IsNullOrEmpty(firstName.Text) || string.IsNullOrEmpty(lastName.Text) || string.IsNullOrEmpty(dob.Text) ||
            string.IsNullOrEmpty(mobileNumber.Text) || string.IsNullOrEmpty(gender.SelectedValue) || string.IsNullOrEmpty(motherName.Text) ||
            string.IsNullOrEmpty(category.SelectedValue) || string.IsNullOrEmpty(maritalStatus.SelectedValue) || string.IsNullOrEmpty(parentOccupation.Text) ||
            string.IsNullOrEmpty(annualIncome.Text) || string.IsNullOrEmpty(courseYear.Text) || string.IsNullOrEmpty(courseName.Text) ||
            string.IsNullOrEmpty(courseType.Text) || string.IsNullOrEmpty(presentInstitute.Text) || string.IsNullOrEmpty(presentCourseYear.Text) ||
            string.IsNullOrEmpty(presentCourseType.Text) || string.IsNullOrEmpty(percentage.Text) || string.IsNullOrEmpty(bankName.Text) ||
            string.IsNullOrEmpty(accountNumber.Text) || string.IsNullOrEmpty(ifscCode.Text) || string.IsNullOrEmpty(branchName.Text) ||
            string.IsNullOrEmpty(pincode.Text) || string.IsNullOrEmpty(address.Text) || string.IsNullOrEmpty(taluka.Text) ||
            string.IsNullOrEmpty(district.Text) || string.IsNullOrEmpty(state.Text) || string.IsNullOrEmpty(currentAddress.Text) ||
            string.IsNullOrEmpty(email.Text))
        {
            lblMessage.Text = "Error: All required fields must be filled.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            return;
        }

        // Validate compulsory file uploads
        if (!photoUpload.HasFile || !idProofUpload.HasFile || !marksheetUpload.HasFile ||
            !incomeCertUpload.HasFile || !bankPassbookUpload.HasFile || !casteCertUpload.HasFile)
        {
            lblMessage.Text = "Error: All documents (Photo, ID Proof, Marksheet, Income Certificate, Bank Passbook, Caste Certificate) are required.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            return;
        }

        if (!System.Text.RegularExpressions.Regex.IsMatch(mobileNumber.Text, @"^\d{10}$"))
        {
            lblMessage.Text = "Mobile Number must be a 10-digit number.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            return;
        }

        try
        {
            // Retrieve ApplicationID from ViewState to ensure consistency
            if (ViewState["ApplicationID"] != null)
            {
                ApplicationID = Convert.ToInt32(ViewState["ApplicationID"]);
            }
            else
            {
                throw new Exception("ApplicationID not found in ViewState.");
            }

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                // Log ApplicationID for debugging
                System.Diagnostics.Debug.WriteLine("Updating ApplicationID: " + ApplicationID);

                // Prepare ApplicationID folder
                string uploadBaseDir = Server.MapPath("~/Uploads/");
                string applicationDir = Path.Combine(uploadBaseDir, ApplicationID.ToString());
                if (!Directory.Exists(applicationDir))
                {
                    Directory.CreateDirectory(applicationDir);
                }
                else
                {
                    // Delete existing files in the folder
                    foreach (string file in Directory.GetFiles(applicationDir))
                    {
                        File.Delete(file);
                        System.Diagnostics.Debug.WriteLine("Deleted file: " + file);
                    }
                }

                // Save new files (all are compulsory)
                string photoPath = SaveFile(photoUpload, applicationDir, ApplicationID);
                string idProofPath = SaveFile(idProofUpload, applicationDir, ApplicationID);
                string marksheetPath = SaveFile(marksheetUpload, applicationDir, ApplicationID);
                string incomePath = SaveFile(incomeCertUpload, applicationDir, ApplicationID);
                string bankPassbookPath = SaveFile(bankPassbookUpload, applicationDir, ApplicationID);
                string casteCertPath = SaveFile(casteCertUpload, applicationDir, ApplicationID);

                // Update the application with all new data and paths
                string query = @"UPDATE Applications SET FullName=@FullName, DOB=@DOB, Email=@Email, Phone=@Phone, Gender=@Gender, MotherName=@MotherName, 
                                 Category=@Category, MaritalStatus=@MaritalStatus, ParentOccupation=@ParentOccupation, AnnualFamilyIncome=@AnnualFamilyIncome, 
                                 IsOrphan=@IsOrphan, CourseYear=@CourseYear, CourseName=@CourseName, CourseType=@CourseType, PreviousEducation=@PreviousEducation, 
                                 ExamFees=@ExamFees, AdmissionFees=@AdmissionFees, PresentInstitute=@PresentInstitute, PresentCourseYear=@PresentCourseYear, 
                                 PresentCourseType=@PresentCourseType, Percentage=@Percentage, BankName=@BankName, AccountNumber=@AccountNumber, IFSCCode=@IFSCCode, 
                                 BranchName=@BranchName, Pincode=@Pincode, Address=@Address, Taluka=@Taluka, District=@District, State=@State, CurrentAddress=@CurrentAddress, 
                                 PhotoPath=@PhotoPath, IdProofPath=@IdProofPath, MarksheetPath=@MarksheetPath, IncomePath=@IncomePath, 
                                 BankPassbookPath=@BankPassbookPath, CasteCertPath=@CasteCertPath 
                                 WHERE ApplicationID=@ApplicationID";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    string fullName = (firstName.Text + " " + middleName.Text + " " + lastName.Text).Trim();
                    cmd.Parameters.AddWithValue("@FullName", fullName);
                    cmd.Parameters.AddWithValue("@DOB", dob.Text);
                    cmd.Parameters.AddWithValue("@Email", email.Text.ToLower());
                    cmd.Parameters.AddWithValue("@Phone", mobileNumber.Text);

                    decimal parsedAnnualIncome;
                    if (!decimal.TryParse(annualIncome.Text, out parsedAnnualIncome) || parsedAnnualIncome <= 0)
                    {
                        throw new Exception("Annual Family Income must be a valid positive number.");
                    }
                    cmd.Parameters.AddWithValue("@AnnualFamilyIncome", parsedAnnualIncome);

                    cmd.Parameters.AddWithValue("@Gender", gender.SelectedValue);
                    cmd.Parameters.AddWithValue("@MotherName", motherName.Text);
                    cmd.Parameters.AddWithValue("@Category", category.SelectedValue);
                    cmd.Parameters.AddWithValue("@MaritalStatus", maritalStatus.SelectedValue);
                    cmd.Parameters.AddWithValue("@ParentOccupation", parentOccupation.Text);
                    cmd.Parameters.AddWithValue("@IsOrphan", isOrphan.Checked);
                    cmd.Parameters.AddWithValue("@CourseYear", courseYear.Text);
                    cmd.Parameters.AddWithValue("@CourseName", courseName.Text);
                    cmd.Parameters.AddWithValue("@CourseType", courseType.Text);
                    cmd.Parameters.AddWithValue("@PreviousEducation", string.IsNullOrEmpty(previousEducation.Text) ? (object)DBNull.Value : previousEducation.Text);

                    decimal? parsedExamFees = null;
                    if (!string.IsNullOrEmpty(examFees.Text))
                    {
                        decimal tempExamFees;
                        if (!decimal.TryParse(examFees.Text, out tempExamFees) || tempExamFees < 0)
                        {
                            throw new Exception("Exam Fees must be a valid non-negative number.");
                        }
                        parsedExamFees = tempExamFees;
                    }
                    cmd.Parameters.AddWithValue("@ExamFees", (object)parsedExamFees ?? DBNull.Value);

                    decimal? parsedAdmissionFees = null;
                    if (!string.IsNullOrEmpty(admissionFees.Text))
                    {
                        decimal tempAdmissionFees;
                        if (!decimal.TryParse(admissionFees.Text, out tempAdmissionFees) || tempAdmissionFees < 0)
                        {
                            throw new Exception("Admission Fees must be a valid non-negative number.");
                        }
                        parsedAdmissionFees = tempAdmissionFees;
                    }
                    cmd.Parameters.AddWithValue("@AdmissionFees", (object)parsedAdmissionFees ?? DBNull.Value);

                    cmd.Parameters.AddWithValue("@PresentInstitute", presentInstitute.Text);
                    cmd.Parameters.AddWithValue("@PresentCourseYear", presentCourseYear.Text);
                    cmd.Parameters.AddWithValue("@PresentCourseType", presentCourseType.Text);

                    decimal parsedPercentage;
                    if (!decimal.TryParse(percentage.Text, out parsedPercentage) || parsedPercentage < 0 || parsedPercentage > 100)
                    {
                        throw new Exception("Percentage must be a valid number between 0 and 100.");
                    }
                    cmd.Parameters.AddWithValue("@Percentage", parsedPercentage);

                    cmd.Parameters.AddWithValue("@BankName", bankName.Text);
                    cmd.Parameters.AddWithValue("@AccountNumber", accountNumber.Text);
                    cmd.Parameters.AddWithValue("@IFSCCode", ifscCode.Text);
                    cmd.Parameters.AddWithValue("@BranchName", branchName.Text);

                    int parsedPincode;
                    if (!int.TryParse(pincode.Text, out parsedPincode) || parsedPincode <= 0)
                    {
                        throw new Exception("Pincode must be a valid positive number.");
                    }
                    cmd.Parameters.AddWithValue("@Pincode", parsedPincode);

                    cmd.Parameters.AddWithValue("@Address", address.Text);
                    cmd.Parameters.AddWithValue("@Taluka", taluka.Text);
                    cmd.Parameters.AddWithValue("@District", district.Text);
                    cmd.Parameters.AddWithValue("@State", state.Text);
                    cmd.Parameters.AddWithValue("@CurrentAddress", currentAddress.Text);

                    cmd.Parameters.AddWithValue("@PhotoPath", photoPath);
                    cmd.Parameters.AddWithValue("@IdProofPath", idProofPath);
                    cmd.Parameters.AddWithValue("@MarksheetPath", marksheetPath);
                    cmd.Parameters.AddWithValue("@IncomePath", incomePath);
                    cmd.Parameters.AddWithValue("@BankPassbookPath", bankPassbookPath);
                    cmd.Parameters.AddWithValue("@CasteCertPath", casteCertPath);
                    cmd.Parameters.AddWithValue("@ApplicationID", ApplicationID);

                    // Log query and parameters for debugging
                    System.Diagnostics.Debug.WriteLine("Query: " + query);
                    foreach (SqlParameter param in cmd.Parameters)
                    {
                        System.Diagnostics.Debug.WriteLine(String.Format("{0}: {1}", param.ParameterName, param.Value));
                    }

                    int rowsAffected = cmd.ExecuteNonQuery();
                    System.Diagnostics.Debug.WriteLine("Rows affected: " + rowsAffected);
                    if (rowsAffected == 0)
                    {
                        throw new Exception("No rows were updated. Please check the ApplicationID.");
                    }

                    lblMessage.Text = "Application updated successfully!";
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Application updated successfully!');", true);
                    Response.Redirect("ApplicantDashboard.aspx");
                }
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
            lblMessage.ForeColor = System.Drawing.Color.Red;
        }
    }

    private string SaveFile(System.Web.UI.WebControls.FileUpload fileUpload, string uploadDir, int applicationId)
    {
        if (fileUpload.HasFile)
        {
            string fileName = Path.GetFileName(fileUpload.FileName);
            string extension = Path.GetExtension(fileName).ToLower();
            string[] validExtensions = { ".pdf", ".jpg" };
            if (Array.IndexOf(validExtensions, extension) == -1)
            {
                throw new Exception("Invalid file type. Please upload only PDF or JPG files.");
            }

            if (fileUpload.PostedFile.ContentLength > 5 * 1024 * 1024)
            {
                throw new Exception("File size must not exceed 5MB.");
            }

            // Log the applicationId being used
            System.Diagnostics.Debug.WriteLine("Saving file for ApplicationID: " + applicationId + ", File: " + fileName);

            string filePath = Path.Combine(uploadDir, fileName);
            fileUpload.SaveAs(filePath); // Save new file directly, old file already deleted
            return String.Format("~/Uploads/{0}/{1}", applicationId, fileName);
        }
        throw new Exception("File upload failed."); // Shouldn’t reach here due to prior validation
    }

    private bool IsApplicationSubmissionEnabled()
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT ApplicationSubmissionEnabled FROM Settings WHERE SettingID = 1";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                object result = cmd.ExecuteScalar();
                if (result != null)
                {
                    return (bool)result;
                }
                return true; // Default to enabled if no setting exists
            }
        }
    }
}