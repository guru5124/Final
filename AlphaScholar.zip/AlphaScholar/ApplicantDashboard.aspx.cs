﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Web.UI.WebControls;

public partial class ApplicantDashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadApplicantData();
            LoadApplications();
        }
    }

    private void LoadApplicantData()
    {
        string applicantEmail = Session["ApplicantEmail"] as string;
        if (string.IsNullOrEmpty(applicantEmail))
        {
            lblSessionError.Text = "Your session has expired. Please log in again.";
            lblSessionError.Visible = true;
            Response.Redirect("Home.aspx");
            return;
        }

        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT FullName, Email, Phone, Gender FROM Applicants WHERE Email = @Email";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Email", applicantEmail.ToLower());
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    litFullName.Text = reader["FullName"].ToString();
                    litProfileName.Text = reader["FullName"].ToString();
                    litEmail.Text = reader["Email"].ToString();
                    litPhone.Text = reader["Phone"].ToString();
                    litGender.Text = reader["Gender"].ToString();
                }
            }
        }
    }

    private void LoadApplications()
    {
        string applicantEmail = Session["ApplicantEmail"] as string;
        if (string.IsNullOrEmpty(applicantEmail))
        {
            lblSessionError.Text = "Your session has expired. Please log in again.";
            lblSessionError.Visible = true;
            System.Diagnostics.Debug.WriteLine("ApplicantEmail session is null or empty");
            return;
        }

        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            try
            {
                conn.Open();
                string query = "SELECT ApplicationID, Status, SubmissionDate, Remark FROM Applications WHERE Email = @Email";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Email", applicantEmail.ToLower());
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    System.Diagnostics.Debug.WriteLine("Found " + dt.Rows.Count + " applications for email: " + applicantEmail.ToLower());
                    foreach (DataRow row in dt.Rows)
                    {
                        System.Diagnostics.Debug.WriteLine("ApplicationID: " + row["ApplicationID"] + ", Status: " + row["Status"]);
                    }

                    if (dt.Rows.Count > 0)
                    {
                        rptApplications.DataSource = dt;
                        rptApplications.DataBind();
                        pnlApplications.Visible = true;
                        pnlNoApplications.Visible = false;
                    }
                    else
                    {
                        pnlApplications.Visible = false;
                        pnlNoApplications.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                lblSessionError.Text = "Error loading applications: " + ex.Message;
                lblSessionError.Visible = true;
                System.Diagnostics.Debug.WriteLine("Application load error: " + ex.Message);
                pnlApplications.Visible = false;
                pnlNoApplications.Visible = true;
            }
        }
    }

    protected void rptApplications_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        string applicationID = e.CommandArgument.ToString();
        if (e.CommandName == "View")
        {
            ViewApplicationAsPDF(applicationID);
        }
        else if (e.CommandName == "Edit")
        {
            System.Diagnostics.Debug.WriteLine("Redirecting to EditApplication.aspx with ApplicationID: " + applicationID);
            Response.Redirect("EditApplication.aspx?ApplicationID=" + applicationID);
        }
        else if (e.CommandName == "Withdraw")
        {
            DeleteApplication(applicationID);
        }
    }

    private void DeleteApplication(string applicationID)
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        string[] filePaths = new string[6];

        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();

            string getFilesQuery = "SELECT PhotoPath, IdProofPath, MarksheetPath, IncomePath, BankPassbookPath, CasteCertPath FROM Applications WHERE ApplicationID = @ApplicationID";
            using (SqlCommand getFilesCmd = new SqlCommand(getFilesQuery, conn))
            {
                getFilesCmd.Parameters.AddWithValue("@ApplicationID", applicationID);
                SqlDataReader reader = getFilesCmd.ExecuteReader();

                if (reader.Read())
                {
                    for (int i = 0; i < filePaths.Length; i++)
                    {
                        filePaths[i] = reader[i].ToString();
                    }
                }
                reader.Close();
            }

            string deleteQuery = "DELETE FROM Applications WHERE ApplicationID = @ApplicationID";
            using (SqlCommand deleteCmd = new SqlCommand(deleteQuery, conn))
            {
                deleteCmd.Parameters.AddWithValue("@ApplicationID", applicationID);
                deleteCmd.ExecuteNonQuery();
            }
        }

        foreach (string filePath in filePaths)
        {
            if (!string.IsNullOrEmpty(filePath))
            {
                try
                {
                    string relativePath = filePath.StartsWith("~") ? filePath : "~" + filePath;
                    string fullPath = Server.MapPath(relativePath);

                    if (File.Exists(fullPath))
                    {
                        File.Delete(fullPath);
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine("File deletion error: " + ex.Message);
                }
            }
        }

        LoadApplications();
    }

    protected string GetStatusColor(string status)
    {
        switch (status.ToLower())
        {
            case "pending":
                return "#f39c12"; // Orange
            case "approved":
                return "#2ecc71"; // Green
            case "rejected":
                return "#e74c3c"; // Red
            default:
                return "#95a5a6"; // Grey for unknown status
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("Home.aspx");
    }

    private void ViewApplicationAsPDF(string applicationID)
    {
        string connStr = ConfigurationManager.ConnectionStrings["ScholarshipDB"].ConnectionString;
        string fullName = "", dob = "", email = "", phone = "", gender = "", address = "", motherName = "", category = "",
               maritalStatus = "", parentOccupation = "", annualFamilyIncome = "", isOrphan = "", courseYear = "",
               courseName = "", courseType = "", previousEducation = "", examFees = "", admissionFees = "",
               presentInstitute = "", presentCourseYear = "", presentCourseType = "", percentage = "",
               bankName = "", accountNumber = "", ifscCode = "", branchName = "", pincode = "",
               taluka = "", district = "", state = "", currentAddress = "", status = "", submissionDate = "",
               remark = "", photoPath = "", idProofPath = "", marksheetPath = "", incomePath = "",
               bankPassbookPath = "", casteCertPath = "";

        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT FullName, DOB, Email, Phone, Gender, Address, MotherName, Category, MaritalStatus, ParentOccupation, " +
                           "AnnualFamilyIncome, IsOrphan, CourseYear, CourseName, CourseType, PreviousEducation, ExamFees, " +
                           "AdmissionFees, PresentInstitute, PresentCourseYear, PresentCourseType, Percentage, BankName, " +
                           "AccountNumber, IFSCCode, BranchName, Pincode, Taluka, District, State, CurrentAddress, " +
                           "SubmissionDate, Status, Remark, PhotoPath, IdProofPath, MarksheetPath, IncomePath, " +
                           "BankPassbookPath, CasteCertPath " +
                           "FROM Applications WHERE ApplicationID = @ApplicationID";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@ApplicationID", applicationID);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    fullName = reader["FullName"].ToString();
                    dob = Convert.ToDateTime(reader["DOB"]).ToString("dd/MM/yyyy");
                    email = reader["Email"].ToString();
                    phone = reader["Phone"].ToString();
                    gender = reader["Gender"].ToString();
                    address = reader["Address"].ToString();
                    motherName = reader["MotherName"].ToString();
                    category = reader["Category"].ToString();
                    maritalStatus = reader["MaritalStatus"].ToString();
                    parentOccupation = reader["ParentOccupation"].ToString();
                    annualFamilyIncome = reader["AnnualFamilyIncome"] != DBNull.Value ? reader["AnnualFamilyIncome"].ToString() : "Not Provided";
                    isOrphan = Convert.ToBoolean(reader["IsOrphan"]) ? "Yes" : "No";
                    courseYear = reader["CourseYear"].ToString();
                    courseName = reader["CourseName"].ToString();
                    courseType = reader["CourseType"].ToString();
                    previousEducation = reader["PreviousEducation"] != DBNull.Value ? reader["PreviousEducation"].ToString() : "Not Provided";
                    examFees = reader["ExamFees"] != DBNull.Value ? reader["ExamFees"].ToString() : "Not Provided";
                    admissionFees = reader["AdmissionFees"] != DBNull.Value ? reader["AdmissionFees"].ToString() : "Not Provided";
                    presentInstitute = reader["PresentInstitute"].ToString();
                    presentCourseYear = reader["PresentCourseYear"].ToString();
                    presentCourseType = reader["PresentCourseType"].ToString();
                    percentage = reader["Percentage"].ToString();
                    bankName = reader["BankName"].ToString();
                    accountNumber = reader["AccountNumber"].ToString();
                    ifscCode = reader["IFSCCode"].ToString();
                    branchName = reader["BranchName"].ToString();
                    pincode = reader["Pincode"].ToString();
                    taluka = reader["Taluka"].ToString();
                    district = reader["District"].ToString();
                    state = reader["State"].ToString();
                    currentAddress = reader["CurrentAddress"].ToString();
                    submissionDate = Convert.ToDateTime(reader["SubmissionDate"]).ToString("dd/MM/yyyy HH:mm:ss");
                    status = reader["Status"].ToString();
                    remark = reader["Remark"] != DBNull.Value ? reader["Remark"].ToString() : "Not Provided";
                    photoPath = reader["PhotoPath"] != DBNull.Value ? reader["PhotoPath"].ToString() : "";
                    idProofPath = reader["IdProofPath"] != DBNull.Value ? reader["IdProofPath"].ToString() : "";
                    marksheetPath = reader["MarksheetPath"] != DBNull.Value ? reader["MarksheetPath"].ToString() : "";
                    incomePath = reader["IncomePath"] != DBNull.Value ? reader["IncomePath"].ToString() : "";
                    bankPassbookPath = reader["BankPassbookPath"] != DBNull.Value ? reader["BankPassbookPath"].ToString() : "";
                    casteCertPath = reader["CasteCertPath"] != DBNull.Value ? reader["CasteCertPath"].ToString() : "";
                }
            }
        }

        // Properly formatted HTML string with document links and View buttons
        string htmlContent = "<html>" +
            "<head>" +
            "<title>Application Details</title>" +
            "<style>" +
            "body { font-family: Arial, sans-serif; padding: 20px; background-color: #f4f4f4; }" +
            ".container { width: 80%; margin: auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0px 0px 10px #ccc; }" +
            "h2 { text-align: center; color: #2d3e50; }" +
            "table { width: 100%; border-collapse: collapse; margin-top: 20px; }" +
            "table, th, td { border: 1px solid #ccc; }" +
            "th, td { padding: 10px; text-align: left; }" +
            "th { background: #2d3e50; color: white; }" +
            "a { color: #3498db; text-decoration: none; }" +
            "a:hover { text-decoration: underline; }" +
            ".view-btn { padding: 5px 10px; background: #3498db; color: white; border: none; border-radius: 4px; cursor: pointer; margin-left: 10px; }" +
            ".view-btn:hover { background: #2980b9; }" +
            ".print-btn { text-align: center; margin-top: 20px; }" +
            ".print-btn button { padding: 10px 15px; background: #2d3e50; color: white; border: none; cursor: pointer; font-size: 16px; }" +
            ".print-btn button:hover { background: #1a2533; }" +
            "</style>" +
            "</head>" +
            "<body>" +
            "<div class='container'>" +
            "<h2>Scholarship Application Details</h2>" +
            "<table>" +
            "<tr><th>Application ID</th><td>" + applicationID + "</td></tr>" +
            "<tr><th>Full Name</th><td>" + fullName + "</td></tr>" +
            "<tr><th>Date of Birth</th><td>" + dob + "</td></tr>" +
            "<tr><th>Email</th><td>" + email + "</td></tr>" +
            "<tr><th>Phone</th><td>" + phone + "</td></tr>" +
            "<tr><th>Gender</th><td>" + gender + "</td></tr>" +
            "<tr><th>Address</th><td>" + address + "</td></tr>" +
            "<tr><th>Mother's Name</th><td>" + motherName + "</td></tr>" +
            "<tr><th>Category</th><td>" + category + "</td></tr>" +
            "<tr><th>Marital Status</th><td>" + maritalStatus + "</td></tr>" +
            "<tr><th>Parent Occupation</th><td>" + parentOccupation + "</td></tr>" +
            "<tr><th>Annual Family Income</th><td>" + annualFamilyIncome + "</td></tr>" +
            "<tr><th>Is Orphan?</th><td>" + isOrphan + "</td></tr>" +
            "<tr><th>Course Year</th><td>" + courseYear + "</td></tr>" +
            "<tr><th>Course Name</th><td>" + courseName + "</td></tr>" +
            "<tr><th>Course Type</th><td>" + courseType + "</td></tr>" +
            "<tr><th>Previous Education</th><td>" + previousEducation + "</td></tr>" +
            "<tr><th>Exam Fees</th><td>" + examFees + "</td></tr>" +
            "<tr><th>Admission Fees</th><td>" + admissionFees + "</td></tr>" +
            "<tr><th>Present Institute</th><td>" + presentInstitute + "</td></tr>" +
            "<tr><th>Present Course Year</th><td>" + presentCourseYear + "</td></tr>" +
            "<tr><th>Present Course Type</th><td>" + presentCourseType + "</td></tr>" +
            "<tr><th>Percentage</th><td>" + percentage + "</td></tr>" +
            "<tr><th>Bank Name</th><td>" + bankName + "</td></tr>" +
            "<tr><th>Account Number</th><td>" + accountNumber + "</td></tr>" +
            "<tr><th>IFSC Code</th><td>" + ifscCode + "</td></tr>" +
            "<tr><th>Branch Name</th><td>" + branchName + "</td></tr>" +
            "<tr><th>Pincode</th><td>" + pincode + "</td></tr>" +
            "<tr><th>Taluka</th><td>" + taluka + "</td></tr>" +
            "<tr><th>District</th><td>" + district + "</td></tr>" +
            "<tr><th>State</th><td>" + state + "</td></tr>" +
            "<tr><th>Current Address</th><td>" + currentAddress + "</td></tr>" +
            "<tr><th>Submission Date</th><td>" + submissionDate + "</td></tr>" +
            "<tr><th>Status</th><td>" + status + "</td></tr>" +
            "<tr><th>Remark</th><td>" + remark + "</td></tr>" +
            "<tr><th>Photo</th><td><a href='" + ResolveUrl(photoPath) + "' target='_blank'>View Photo</a> <button class='view-btn' onclick='window.open(\"" + ResolveUrl(photoPath) + "\", \"_blank\");'>View</button></td></tr>" +
            "<tr><th>ID Proof</th><td><a href='" + ResolveUrl(idProofPath) + "' target='_blank'>View ID Proof</a> <button class='view-btn' onclick='window.open(\"" + ResolveUrl(idProofPath) + "\", \"_blank\");'>View</button></td></tr>" +
            "<tr><th>Marksheet</th><td><a href='" + ResolveUrl(marksheetPath) + "' target='_blank'>View Marksheet</a> <button class='view-btn' onclick='window.open(\"" + ResolveUrl(marksheetPath) + "\", \"_blank\");'>View</button></td></tr>" +
            "<tr><th>Income Certificate</th><td><a href='" + ResolveUrl(incomePath) + "' target='_blank'>View Income Certificate</a> <button class='view-btn' onclick='window.open(\"" + ResolveUrl(incomePath) + "\", \"_blank\");'>View</button></td></tr>" +
            "<tr><th>Bank Passbook</th><td><a href='" + ResolveUrl(bankPassbookPath) + "' target='_blank'>View Bank Passbook</a> <button class='view-btn' onclick='window.open(\"" + ResolveUrl(bankPassbookPath) + "\", \"_blank\");'>View</button></td></tr>" +
            "<tr><th>Caste Certificate</th><td><a href='" + ResolveUrl(casteCertPath) + "' target='_blank'>View Caste Certificate</a> <button class='view-btn' onclick='window.open(\"" + ResolveUrl(casteCertPath) + "\", \"_blank\");'>View</button></td></tr>" +
            "</table>" +
            "<div class='print-btn'>" +
            "<button onclick='openPrintWindow();'>Print / Save as PDF</button>" +
            "</div>" +
            "</div>" +
            "<script type='text/javascript'>" +
            "function openPrintWindow() {" +
            "var content = document.querySelector('.container').innerHTML;" +
            "var printWindow = window.open('', '_blank');" +
            "var styles = '<style>" +
            "body { font-family: Arial, sans-serif; padding: 20px; background-color: #f4f4f4; }" +
            ".container { width: 80%; margin: auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0px 0px 10px #ccc; }" +
            "h2 { text-align: center; color: #2d3e50; }" +
            "table { width: 100%; border-collapse: collapse; margin-top: 20px; }" +
            "table, th, td { border: 1px solid #ccc; }" +
            "th, td { padding: 10px; text-align: left; }" +
            "th { background: #2d3e50; color: white; }" +
            "a { color: #3498db; text-decoration: none; }" +
            "a:hover { text-decoration: underline; }" +
            ".view-btn { display: none; }" +
            ".print-btn { display: none; }" +
            "</style>';" +
            "printWindow.document.write('<html><head><title>Print Application</title>' + styles + '</head><body>' + content + '</body></html>');" +
            "printWindow.document.close();" +
            "printWindow.focus();" +
            "printWindow.print();" +
            "printWindow.close();" +
            "}" +
            "</script>" +
            "</body>" +
            "</html>";

        Response.Clear();
        Response.ContentType = "text/html";
        Response.Write(htmlContent);
        Response.Flush();
        Response.SuppressContent = true;
        HttpContext.Current.ApplicationInstance.CompleteRequest();
    }
}