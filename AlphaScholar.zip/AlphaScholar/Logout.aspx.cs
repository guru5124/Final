﻿using System;

public partial class Logout : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Clear the session
        Session.Clear();
        Session.Abandon();

        // Display logout message
        lblLogoutMessage.Text = "You have been logged out. Redirecting...";

        // Redirect to Home.aspx after a 2-second delay
        ClientScript.RegisterStartupScript(this.GetType(), "redirect", "setTimeout(function(){window.location='Home.aspx';}, 2000);", true);
    }
}