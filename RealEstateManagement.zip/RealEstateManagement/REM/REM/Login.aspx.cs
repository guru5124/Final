﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace REM
{
    public partial class Login : System.Web.UI.Page
    {
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            // Hardcoded Admin Check
            if (username == "admin" && password == "admin")
            {
                // Start session for admin
                Session["Username"] = "admin";
                Session["UserRole"] = "Admin";
                Response.Redirect("admin.aspx");
                return; // Stop further execution
            }

            // Database Validation
            if (ValidateUser(username, password))
            {
                // Start session for authenticated user
                Session["Username"] = username;
                // Optionally, set additional session values (e.g., roles, user ID, etc.)
                Response.Redirect("Account.aspx");
            }
            else
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.Text = "Invalid username or password.";
            }
        }

        private bool ValidateUser(string username, string password)
        {
            // Retrieve connection string from web.config
            string connectionString = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            string query = "SELECT ID, UserType FROM Users WHERE Username = @Username AND Password = @Password";
    
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Use parameters to prevent SQL injection
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);
                    connection.Open();
            
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        // Store user ID and type in session
                        Session["UserID"] = reader["ID"].ToString();
                        Session["UserType"] = reader["UserType"].ToString();
                        reader.Close();
                        return true;
                    }
            
                    return false;
                }
            }
        }
    }
}
