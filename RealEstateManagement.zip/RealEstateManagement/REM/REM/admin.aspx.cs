﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.IO;

namespace REM
{
    public partial class admin : System.Web.UI.Page
    {
        // Get connection string from web.config
        private string connectionString = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Load users data
                LoadUsers();
            }
        }

        private void LoadUsers()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    // Updated column names to match the actual database schema
                    SqlCommand cmd = new SqlCommand("SELECT ID, Username AS Name, Email, PhNo AS PhoneNumber, UserType FROM Users ORDER BY ID", conn);
                    conn.Open();

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        gvUsers.DataSource = dt;
                        gvUsers.DataBind();
                    }
                    else
                    {
                        // Show a message if no users found
                        pnlMessage.Visible = true;
                        pnlMessage.CssClass = "message error";
                        litMessage.Text = "No users found in the database.";
                    }
                }
            }
            catch (Exception ex)
            {
                // Display error message
                ShowMessage("Error: " + ex.Message, false);
            }
        }

        protected void gvUsers_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DeleteUser")
            {
                int userId = Convert.ToInt32(e.CommandArgument);
                DeleteUser(userId);
            }
        }

        private void DeleteUser(int userId)
        {
            // Don't allow deleting the current admin
            if (Session["UserID"] != null && Convert.ToInt32(Session["UserID"]) == userId)
            {
                ShowMessage("Cannot delete your own account while logged in.", false);
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlTransaction transaction = conn.BeginTransaction();

                    try
                    {
                        // Delete related records from ApprovedAppointment table
                        using (SqlCommand cmd = new SqlCommand("DELETE FROM ApprovedAppointment WHERE BuyerID = @UserID OR SellerID = @UserID", conn, transaction))
                        {
                            cmd.Parameters.AddWithValue("@UserID", userId);
                            cmd.ExecuteNonQuery();
                        }

                        // Delete related records from RequestAppointment table
                        using (SqlCommand cmd = new SqlCommand("DELETE FROM RequestAppointment WHERE BuyerID = @UserID OR SellerID = @UserID", conn, transaction))
                        {
                            cmd.Parameters.AddWithValue("@UserID", userId);
                            cmd.ExecuteNonQuery();
                        }

                        // Delete related records from Buyer table
                        using (SqlCommand cmd = new SqlCommand("DELETE FROM Buyer WHERE ID = @UserID", conn, transaction))
                        {
                            cmd.Parameters.AddWithValue("@UserID", userId);
                            cmd.ExecuteNonQuery();
                        }

                        // Delete related records from Sell table
                        using (SqlCommand cmd = new SqlCommand("DELETE FROM Sell WHERE ID = @UserID", conn, transaction))
                        {
                            cmd.Parameters.AddWithValue("@UserID", userId);
                            cmd.ExecuteNonQuery();
                        }

                        // Finally, delete the user
                        using (SqlCommand cmd = new SqlCommand("DELETE FROM Users WHERE ID = @UserID", conn, transaction))
                        {
                            cmd.Parameters.AddWithValue("@UserID", userId);
                            cmd.ExecuteNonQuery();
                        }

                        // Commit transaction if all commands succeeded
                        transaction.Commit();
                        ShowMessage("User and all related records deleted successfully.", true);

                        // Reload users data
                        LoadUsers();
                    }
                    catch (Exception ex)
                    {
                        // Rollback transaction on error
                        transaction.Rollback();
                        ShowMessage("Error deleting user: " + ex.Message, false);
                    }
                }
            }
            catch (Exception ex)
            {
                ShowMessage("Database connection error: " + ex.Message, false);
            }
        }

        protected void btnReport_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewReport.aspx");
        }

        private void ShowMessage(string message, bool isSuccess)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isSuccess ? "message success" : "message error";
            litMessage.Text = message;
        }
    }
}