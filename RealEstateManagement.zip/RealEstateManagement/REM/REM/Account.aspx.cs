﻿using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace REM
{
    public partial class Account : System.Web.UI.Page
    {
        private string loggedInUserId = "";
        private string userType = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            // Check if user is logged in
            if (Session["Username"] == null)
            {
                Response.Redirect("Login.aspx");
                return;
            }

            // Get logged in user information
            string username = Session["Username"].ToString();

            // Retrieve user ID from database based on username
            loggedInUserId = GetUserIdFromUsername(username);

            if (loggedInUserId == "")
            {
                // Handle error - redirect to login
                Response.Redirect("Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                // Load user data and property listings
                LoadUserData();
                LoadPropertyListings();

                // Load appointment requests if the modal is opened
                if (Request.QueryString["modal"] == "sellerAppointment")
                {
                    string propertyId = hdnSelectedPropertyID.Value;
                    if (!string.IsNullOrEmpty(propertyId))
                    {
                        LoadAppointmentRequests(propertyId);
                    }
                }
            }
        }

        private string GetUserIdFromUsername(string username)
        {
            string userId = "";
            string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT ID FROM Users WHERE Username=@Username", conn);
                    cmd.Parameters.AddWithValue("@Username", username);

                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        userId = result.ToString();
                    }
                }
                catch (Exception ex)
                {
                    // Log error
                    System.Diagnostics.Debug.WriteLine("Error getting user ID: " + ex.Message);
                }
            }

            return userId;
        }

        // The rest of your methods remain the same
        private void LoadUserData()
        {
            string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT Username, UserType, ProfilePicPath FROM Users WHERE ID=@ID", conn);
                    cmd.Parameters.AddWithValue("@ID", loggedInUserId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        lblUsername.Text = "Welcome, " + reader["Username"].ToString();
                        userType = reader["UserType"].ToString(); // Ensure this is set correctly
                        hdnUserType.Value = userType; // Set the hidden field value
                        btnAddEstate.CommandArgument = userType;
                        string profilePicPath = reader["ProfilePicPath"].ToString();
                        ProfilePic.ImageUrl = string.IsNullOrEmpty(profilePicPath) ? "~/Images/default.jpg" : profilePicPath;
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    Response.Write("Error loading user data: " + ex.Message);
                }
            }
        }

        private void LoadPropertyListings()
        {
            string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd;

                    if (userType == "Seller")
                    {
                        // Sellers see their own properties
                        cmd = new SqlCommand("SELECT * FROM Sell WHERE ID=@ID ORDER BY DateListed DESC", conn);
                        cmd.Parameters.AddWithValue("@ID", loggedInUserId);

                        listingsTitle.InnerText = "Your Listed Properties";
                        btnDeleteProperty.Visible = true;
                    }
                    else if (userType == "Buyer")
                    {
                        // Buyers see properties they've saved/shortlisted from the Buyer table
                        cmd = new SqlCommand(@"
                    SELECT 
                        BuyerID,
                        SellID,
                        ID,
                        SellerName,
                        PicOfProperty,
                        PropertyName,
                        Price,
                        Type,
                        Size,
                        Address,
                        SellerNo,
                        DateListed
                    FROM Buyer 
                    WHERE ID = @ID 
                    ORDER BY DateListed DESC", conn);
                        cmd.Parameters.AddWithValue("@ID", loggedInUserId);

                        listingsTitle.InnerText = "Your Saved Properties";
                        btnDeleteProperty.Visible = true; // Enable delete button for buyers
                    }
                    else
                    {
                        // Default case - no properties to show
                        rptProperties.DataSource = null;
                        rptProperties.DataBind();
                        pnlNoProperties.Visible = true;
                        return;
                    }

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        rptProperties.DataSource = dt;
                        rptProperties.DataBind();
                        pnlNoProperties.Visible = false;
                    }
                    else
                    {
                        rptProperties.DataSource = null;
                        rptProperties.DataBind();
                        pnlNoProperties.Visible = true;
                    }
                }
                catch (Exception ex)
                {
                    string errorMsg = "Error loading property listings: " + ex.Message;
                    if (ex.InnerException != null)
                        errorMsg += " Inner: " + ex.InnerException.Message;

                    Response.Write("<script>console.log('" + errorMsg.Replace("'", "\\'") + "');</script>");
                    Response.Write("<!-- Debug Error: " + errorMsg + " -->");
                }
            }
        }

        private void UploadProfilePicture()
        {
            try
            {
                string fileName = Path.GetFileName(FileUpload1.FileName);
                string folderPath = Server.MapPath("~/Images/");

                // Ensure directory exists
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                // Add timestamp to filename to avoid caching issues
                string timestamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                string uniqueFileName = Path.GetFileNameWithoutExtension(fileName) + "_" + timestamp + Path.GetExtension(fileName);
                string filePath = "~/Images/" + uniqueFileName;

                FileUpload1.SaveAs(Server.MapPath(filePath));

                // Update database
                string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE Users SET ProfilePicPath=@ProfilePicPath WHERE ID=@ID", conn);
                    cmd.Parameters.AddWithValue("@ProfilePicPath", filePath);
                    cmd.Parameters.AddWithValue("@ID", loggedInUserId);
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // Update UI
                        ProfilePic.ImageUrl = filePath;
                        lblUploadInfo.Text = "Profile picture updated successfully!";
                        lblUploadInfo.ForeColor = System.Drawing.Color.Green;
                        lblUploadInfo.Visible = true;
                    }
                    else
                    {
                        lblUploadInfo.Text = "Failed to update profile picture in database.";
                        lblUploadInfo.ForeColor = System.Drawing.Color.Red;
                        lblUploadInfo.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                lblUploadInfo.Text = "Error: " + ex.Message;
                lblUploadInfo.ForeColor = System.Drawing.Color.Red;
                lblUploadInfo.Visible = true;
            }
        }

        protected void btnAddEstate_Click(object sender, EventArgs e)
        {
            string userType = btnAddEstate.CommandArgument;
            if (userType == "Buyer")
            {
                Response.Redirect("Main.aspx");
            }
            else if (userType == "Seller")
            {
                Response.Redirect("sell.aspx");
            }
        }

        protected void btnDeleteProperty_Click(object sender, EventArgs e)
        {
            try
            {
                string propertyId = hdnSelectedPropertyID.Value;
                if (string.IsNullOrEmpty(propertyId))
                {
                    Response.Write("<script>alert('Please select a property to delete.');</script>");
                    return;
                }

                // Retrieve userType from the hidden field
                string userType = hdnUserType.Value;

                if (string.IsNullOrEmpty(userType))
                {
                    Response.Write("<script>alert('User type is not set.');</script>");
                    return;
                }

                string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();

                    if (userType == "Seller")
                    {
                        // Delete from Sell table for sellers
                        SqlCommand cmd = new SqlCommand("DELETE FROM Sell WHERE SellID=@SellID AND ID=@UserID", conn);
                        cmd.Parameters.AddWithValue("@SellID", propertyId);
                        cmd.Parameters.AddWithValue("@UserID", loggedInUserId);
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            // Delete related records from RequestAppointment table
                            SqlCommand cmdDeleteAppointments = new SqlCommand("DELETE FROM RequestAppointment WHERE PropertyID=@PropertyID", conn);
                            cmdDeleteAppointments.Parameters.AddWithValue("@PropertyID", propertyId);
                            cmdDeleteAppointments.ExecuteNonQuery();

                            Response.Redirect(Request.RawUrl, false);
                            Context.ApplicationInstance.CompleteRequest();
                        }
                        else
                        {
                            Response.Write("<script>alert('Delete failed. Property might not exist.');</script>");
                        }
                    }
                    else if (userType == "Buyer")
                    {
                        // Delete from Buyer table for buyers
                        SqlCommand cmd = new SqlCommand("DELETE FROM Buyer WHERE SellID=@SellID AND ID=@UserID", conn);
                        cmd.Parameters.AddWithValue("@SellID", propertyId);
                        cmd.Parameters.AddWithValue("@UserID", loggedInUserId);
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            // Delete related records from RequestAppointment table
                            SqlCommand cmdDeleteAppointments = new SqlCommand("DELETE FROM RequestAppointment WHERE PropertyID=@PropertyID AND BuyerID=@BuyerID", conn);
                            cmdDeleteAppointments.Parameters.AddWithValue("@PropertyID", propertyId);
                            cmdDeleteAppointments.Parameters.AddWithValue("@BuyerID", loggedInUserId);
                            cmdDeleteAppointments.ExecuteNonQuery();

                            Response.Redirect(Request.RawUrl, false);
                            Context.ApplicationInstance.CompleteRequest();
                        }
                        else
                        {
                            Response.Write("<script>alert('Delete failed. Property might not exist in your saved list.');</script>");
                        }
                    }
                    else
                    {
                        Response.Write("<script>alert('Invalid user type.');</script>");
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
            }
        }

        protected void btnRequestAppointment_Click(object sender, EventArgs e)
        {
            try
            {
                string propertyId = hdnSelectedPropertyID.Value;
                if (string.IsNullOrEmpty(propertyId))
                {
                    Response.Write("<script>alert('Property information is missing.');</script>");
                    return;
                }

                if (!calAppointmentDate.SelectedDate.ToString("d").Contains("0001"))
                {
                    string appointmentDate = calAppointmentDate.SelectedDate.ToString("yyyy-MM-dd");
                    string appointmentTime = txtAppointmentTime.Text.Trim();

                    if (string.IsNullOrEmpty(appointmentTime))
                    {
                        Response.Write("<script>alert('Please enter an appointment time.');</script>");
                        return;
                    }

                    string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                    using (SqlConnection conn = new SqlConnection(connStr))
                    {
                        conn.Open();

                        // First get the necessary information from Sell and Users tables
                        SqlCommand cmdGetInfo = new SqlCommand(@"
                    SELECT s.SellerName, s.PropertyName, s.ID as SellerID, u.Username as BuyerName
                    FROM Sell s, Users u
                    WHERE s.SellID = @SellID AND u.ID = @BuyerID", conn);
                        cmdGetInfo.Parameters.AddWithValue("@SellID", propertyId);
                        cmdGetInfo.Parameters.AddWithValue("@BuyerID", loggedInUserId);

                        SqlDataReader reader = cmdGetInfo.ExecuteReader();
                        if (reader.Read())
                        {
                            string sellerName = reader["SellerName"].ToString();
                            string propertyName = reader["PropertyName"].ToString();
                            string sellerId = reader["SellerID"].ToString();
                            string buyerName = reader["BuyerName"].ToString();

                            reader.Close();

                            // Check if a request already exists for this property
                            SqlCommand cmdCheckExisting = new SqlCommand(@"
                        SELECT COUNT(*) FROM RequestAppointment 
                        WHERE PropertyID = @PropertyID AND BuyerID = @BuyerID", conn);
                            cmdCheckExisting.Parameters.AddWithValue("@PropertyID", propertyId);
                            cmdCheckExisting.Parameters.AddWithValue("@BuyerID", loggedInUserId);

                            int existingRequests = (int)cmdCheckExisting.ExecuteScalar();

                            if (existingRequests > 0)
                            {
                                // Update existing request
                                SqlCommand cmdUpdate = new SqlCommand(@"
                            UPDATE RequestAppointment SET 
                            AppointmentDate = @AppointmentDate,
                            AppointmentTime = @AppointmentTime,
                            Status = 'Pending'
                            WHERE PropertyID = @PropertyID AND BuyerID = @BuyerID", conn);
                                cmdUpdate.Parameters.AddWithValue("@AppointmentDate", appointmentDate);
                                cmdUpdate.Parameters.AddWithValue("@AppointmentTime", appointmentTime);
                                cmdUpdate.Parameters.AddWithValue("@PropertyID", propertyId);
                                cmdUpdate.Parameters.AddWithValue("@BuyerID", loggedInUserId);

                                cmdUpdate.ExecuteNonQuery();
                                Response.Write("<script>alert('Appointment request updated successfully!');</script>");
                            }
                            else
                            {
                                // Insert new request
                                SqlCommand cmdInsert = new SqlCommand(@"
                            INSERT INTO RequestAppointment 
                            (BuyerID, BuyerName, PropertyID, PropertyName, SellerID, SellerName, AppointmentDate, AppointmentTime, Status)
                            VALUES 
                            (@BuyerID, @BuyerName, @PropertyID, @PropertyName, @SellerID, @SellerName, @AppointmentDate, @AppointmentTime, 'Pending')", conn);

                                cmdInsert.Parameters.AddWithValue("@BuyerID", loggedInUserId);
                                cmdInsert.Parameters.AddWithValue("@BuyerName", buyerName);
                                cmdInsert.Parameters.AddWithValue("@PropertyID", propertyId);
                                cmdInsert.Parameters.AddWithValue("@PropertyName", propertyName);
                                cmdInsert.Parameters.AddWithValue("@SellerID", sellerId);
                                cmdInsert.Parameters.AddWithValue("@SellerName", sellerName);
                                cmdInsert.Parameters.AddWithValue("@AppointmentDate", appointmentDate);
                                cmdInsert.Parameters.AddWithValue("@AppointmentTime", appointmentTime);

                                cmdInsert.ExecuteNonQuery();
                                Response.Write("<script>alert('Appointment request submitted successfully!');</script>");
                            }

                            // Update the request status label
                            lblRequestStatus.Visible = true;
                            lblRequestStatus.Text = "Pending"; // Set the label text to "Pending"

                            // Reset the form
                            calAppointmentDate.SelectedDate = DateTime.MinValue;
                            txtAppointmentTime.Text = string.Empty;

                            // Close the modal
                            ClientScript.RegisterStartupScript(this.GetType(), "closeModal", "closeBuyerAppointmentModal();", true);
                        }
                        else
                        {
                            reader.Close();
                            Response.Write("<script>alert('Failed to retrieve property information.');</script>");
                        }
                    }
                }
                else
                {
                    Response.Write("<script>alert('Please select an appointment date.');</script>");
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            // Load appointment request details when property modal is opened
            if (!string.IsNullOrEmpty(hdnSelectedPropertyID.Value))
            {
                if (userType == "Buyer")
                {
                    CheckExistingAppointment(hdnSelectedPropertyID.Value);
                }
                else if (userType == "Seller")
                {
                    LoadAppointmentRequests(hdnSelectedPropertyID.Value);
                }
            }
        }

        private void CheckExistingAppointment(string propertyId)
        {
            string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();

                    // Check for existing appointment request
                    SqlCommand cmd = new SqlCommand(@"
                SELECT * FROM RequestAppointment 
                WHERE PropertyID = @PropertyID AND BuyerID = @BuyerID", conn);
                    cmd.Parameters.AddWithValue("@PropertyID", propertyId);
                    cmd.Parameters.AddWithValue("@BuyerID", loggedInUserId);

                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // Existing appointment found
                        string status = reader["Status"].ToString();
                        string message = reader["Message"] != DBNull.Value ? reader["Message"].ToString() : string.Empty;

                        // Display seller message if available
                        if (!string.IsNullOrEmpty(message))
                        {
                            lblSellerMessage.Visible = true;
                            txtSellerMessage.Visible = true;
                            txtSellerMessage.Text = message;
                        }

                        // Update the request status label
                        lblRequestStatus.Visible = true;
                        lblRequestStatus.Text = status; // Set the label text to the status
                    }
                    else
                    {
                        // No existing appointment
                        lblRequestStatus.Visible = false;
                        lblSellerMessage.Visible = false;
                        txtSellerMessage.Visible = false;
                        txtSellerMessage.Text = string.Empty;
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
                }
            }
        }

        private void LoadAppointmentRequests(string propertyId)
        {
            string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();

                    // The issue is here - we need to ensure we're using the correct column types
                    SqlCommand cmd = new SqlCommand(@"
                SELECT * FROM RequestAppointment 
                WHERE PropertyID = @PropertyID AND SellerID = @SellerID", conn);
                    cmd.Parameters.AddWithValue("@PropertyID", Convert.ToInt32(propertyId)); // Convert string to int
                    cmd.Parameters.AddWithValue("@SellerID", Convert.ToInt32(loggedInUserId)); // Convert string to int

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        rptAppointmentRequests.DataSource = dt;
                        rptAppointmentRequests.DataBind();
                        pnlNoRequests.Visible = false; // Hide "No Requests" message
                    }
                    else
                    {
                        rptAppointmentRequests.DataSource = null;
                        rptAppointmentRequests.DataBind();
                        pnlNoRequests.Visible = true; // Show "No Requests" message
                    }
                }
                catch (Exception ex)
                {
                    // Add more detailed error logging here
                    string errorMsg = "Error loading appointment requests: " + ex.Message;
                    if (ex.InnerException != null)
                        errorMsg += " Inner: " + ex.InnerException.Message;

                    Response.Write("<script>console.log('" + errorMsg.Replace("'", "\\'") + "');</script>");
                    Response.Write("<!-- Debug Error: " + errorMsg + " -->");
                }
            }
        }

        protected void calAppointmentDate_SelectionChanged(object sender, EventArgs e)
        {
            // Optionally, you can update a label or perform other actions here
            // For example:
            lblRequestStatus.Visible = true;
            lblStatusValue.Text = "Selected Date: " + calAppointmentDate.SelectedDate.ToShortDateString();
        }

        protected void rptAppointmentRequests_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            try
            {
                string requestId = e.CommandArgument.ToString();
                string message = string.Empty;

                // Get the message textbox from the current item
                TextBox txtMessage = (TextBox)e.Item.FindControl("txtMessageToBuyer");
                if (txtMessage != null)
                {
                    message = txtMessage.Text.Trim();
                }

                // Debug to check the requestId value
                Response.Write("<script>console.log('Request ID: " + requestId + "');</script>");

                string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();

                    if (e.CommandName == "Approve")
                    {
                        // Update the RequestAppointment table with the message and status
                        SqlCommand cmdUpdate = new SqlCommand(@"
                    UPDATE RequestAppointment SET 
                    Status = 'Approved', 
                    Message = @Message 
                    WHERE RequestID = @RequestID", conn);
                        cmdUpdate.Parameters.AddWithValue("@Message", message);
                        cmdUpdate.Parameters.AddWithValue("@RequestID", Convert.ToInt32(requestId));
                        int rowsAffected = cmdUpdate.ExecuteNonQuery();

                        // Debug to check if update was successful
                        Response.Write("<script>console.log('Rows updated: " + rowsAffected + "');</script>");

                        // Copy data to ApprovedAppointment table
                        if (rowsAffected > 0)
                        {
                            SqlCommand cmdInsert = new SqlCommand(@"
                        INSERT INTO ApprovedAppointment 
                        (BuyerID, BuyerName, PropertyID, PropertyName, SellerID, SellerName, AppointmentDate, AppointmentTime, Message)
                        SELECT BuyerID, BuyerName, PropertyID, PropertyName, SellerID, SellerName, AppointmentDate, AppointmentTime, @Message
                        FROM RequestAppointment 
                        WHERE RequestID = @RequestID", conn);
                            cmdInsert.Parameters.AddWithValue("@Message", message);
                            cmdInsert.Parameters.AddWithValue("@RequestID", Convert.ToInt32(requestId));
                            cmdInsert.ExecuteNonQuery();

                            Response.Write("<script>alert('Appointment request approved successfully!');</script>");
                        }
                        else
                        {
                            Response.Write("<script>alert('No appointment found with ID: " + requestId + "');</script>");
                        }
                    }
                    else if (e.CommandName == "Reject")
                    {
                        // Similar updates for reject functionality
                        // ...
                    }

                    // Refresh the list of appointment requests
                    LoadAppointmentRequests(hdnSelectedPropertyID.Value);
                }
            }
            catch (Exception ex)
            {
                string errorMsg = "Error: " + ex.Message;
                if (ex.InnerException != null)
                    errorMsg += " Inner: " + ex.InnerException.Message;

                Response.Write("<script>console.log('" + errorMsg.Replace("'", "\\'") + "');</script>");
                Response.Write("<script>alert('" + errorMsg.Replace("'", "\\'") + "');</script>");
            }
        }

        protected void rptProperties_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "ViewAppointments")
            {
                string propertyId = e.CommandArgument.ToString();
                hdnSelectedPropertyID.Value = propertyId;

                // Debug to check the propertyId value
                Response.Write("<script>console.log('Property ID set to: " + propertyId + "');</script>");

                // Load the appointment requests for this property
                LoadAppointmentRequests(propertyId);

                // Use JavaScript to show the modal
                ClientScript.RegisterStartupScript(this.GetType(), "showModal",
                    "document.getElementById('sellerAppointmentModal').style.display = 'block';", true);
            }
        }
    }
}