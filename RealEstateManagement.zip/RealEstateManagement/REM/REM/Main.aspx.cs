﻿using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace REM
{
    public partial class Main : System.Web.UI.Page
    {
        private string loggedInUserId = "";

        // Property to expose user type to JavaScript
        protected string UserType { get; private set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            // Check if user is logged in
            if (Session["Username"] == null)
            {
                Response.Redirect("Login.aspx");
                return;
            }

            // Get logged in user information
            string username = Session["Username"].ToString();

            // If UserID is stored in session, use it directly
            if (Session["UserID"] != null)
            {
                loggedInUserId = Session["UserID"].ToString();
            }
            else
            {
                // Otherwise, retrieve user ID from database based on username
                loggedInUserId = GetUserIdFromUsername(username);

                if (string.IsNullOrEmpty(loggedInUserId))
                {
                    // Handle error - redirect to login
                    Response.Redirect("Login.aspx");
                    return;
                }

                // Store user ID in session for future use
                Session["UserID"] = loggedInUserId;
            }

            if (!IsPostBack)
            {
                // Load user data to determine user type
                LoadUserData();

                // Load all property listings
                LoadPropertyListings();
            }
        }

        private string GetUserIdFromUsername(string username)
        {
            string userId = "";
            string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT ID FROM Users WHERE Username=@Username", conn);
                    cmd.Parameters.AddWithValue("@Username", username);

                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        userId = result.ToString();
                    }
                }
                catch (Exception ex)
                {
                    // Log error
                    System.Diagnostics.Debug.WriteLine("Error getting user ID: " + ex.Message);
                }
            }

            return userId;
        }

        private void LoadUserData()
        {
            string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT UserType FROM Users WHERE ID=@ID", conn);
                    cmd.Parameters.AddWithValue("@ID", loggedInUserId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        UserType = reader["UserType"].ToString();

                        // Store user type in session for use across the application
                        Session["UserType"] = UserType;
                    }
                    else
                    {
                        // Default to Buyer if user not found
                        UserType = "Buyer";
                        Session["UserType"] = UserType;
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    // Log the error or display a message
                    Response.Write("Error loading user data: " + ex.Message);
                    UserType = "Buyer"; // Default if error occurs
                    Session["UserType"] = UserType;
                }
            }
        }

        private void LoadPropertyListings(string propertyType = "", string searchTerm = "")
        {
            string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM Sell WHERE 1=1";

                    // Add filters if specified
                    if (!string.IsNullOrEmpty(propertyType))
                    {
                        query += " AND Type=@Type";
                    }

                    if (!string.IsNullOrEmpty(searchTerm))
                    {
                        query += " AND (PropertyName LIKE @Search OR Address LIKE @Search)";
                    }

                    query += " ORDER BY DateListed DESC";

                    SqlCommand cmd = new SqlCommand(query, conn);

                    if (!string.IsNullOrEmpty(propertyType))
                    {
                        cmd.Parameters.AddWithValue("@Type", propertyType);
                    }

                    if (!string.IsNullOrEmpty(searchTerm))
                    {
                        cmd.Parameters.AddWithValue("@Search", "%" + searchTerm + "%");
                    }

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        rptProperties.DataSource = dt;
                        rptProperties.DataBind();
                        pnlNoProperties.Visible = false;
                    }
                    else
                    {
                        rptProperties.DataSource = null;
                        rptProperties.DataBind();
                        pnlNoProperties.Visible = true;
                    }
                }
                catch (Exception ex)
                {
                    // Log the error or display a message
                    Response.Write("Error loading property listings: " + ex.Message);
                }
            }
        }

        protected void btnFilter_Click(object sender, EventArgs e)
        {
            string propertyType = ddlPropertyType.SelectedValue;
            string searchTerm = txtSearch.Text.Trim();

            LoadPropertyListings(propertyType, searchTerm);
        }

        protected void btnAddToProfile_Click(object sender, EventArgs e)
        {
            string sellId = hdnSelectedPropertyID.Value;
            if (string.IsNullOrEmpty(sellId))
            {
                Response.Write("<script>alert('Please select a property to add to your profile.');</script>");
                return;
            }

            // Check if the property is already in the Buyer's profile
            if (IsPropertyInBuyerProfile(sellId))
            {
                Response.Write("<script>alert('This property is already in your profile.');</script>");
                return;
            }

            AddPropertyToBuyerProfile(sellId);

            // Force a page refresh to ensure UserType is properly reloaded
            Response.Redirect(Request.RawUrl, false);
            Context.ApplicationInstance.CompleteRequest();
        }

        private bool IsPropertyInBuyerProfile(string sellId)
        {
            string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Buyer WHERE SellID=@SellID AND ID=@ID", conn);
                    cmd.Parameters.AddWithValue("@SellID", sellId);
                    cmd.Parameters.AddWithValue("@ID", loggedInUserId);
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
                catch (Exception ex)
                {
                    // Log the error
                    Response.Write("<script>console.log('Error checking buyer profile: " +
                                   ex.Message.Replace("'", "\\'") + "');</script>");
                    return false;
                }
            }
        }

        private void AddPropertyToBuyerProfile(string sellId)
        {
            string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();

                    // First, get the property details from Sell table
                    SqlCommand getCmd = new SqlCommand(
                        "SELECT ID, SellID, SellerName, PicOfProperty, PropertyName, Price, Type, Size, Address, SellerNo " +
                        "FROM Sell WHERE SellID=@SellID", conn);
                    getCmd.Parameters.AddWithValue("@SellID", sellId);
                    SqlDataReader reader = getCmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // Get the original seller's ID from the Sell table
                        int originalSellerId = Convert.ToInt32(reader["ID"]);
                        int sellIdValue = Convert.ToInt32(reader["SellID"]);
                        string sellerName = reader["SellerName"].ToString();
                        string picOfProperty = reader["PicOfProperty"].ToString();
                        string propertyName = reader["PropertyName"].ToString();
                        string price = reader["Price"].ToString();
                        string type = reader["Type"].ToString();
                        string size = reader["Size"].ToString();
                        string address = reader["Address"].ToString();
                        string sellerNo = reader["SellerNo"].ToString();

                        reader.Close();

                        // Now insert into Buyer table with the original seller's ID and SellID
                        SqlCommand insertCmd = new SqlCommand(
                            "INSERT INTO Buyer (BuyerID, ID, SellID, SellerName, PicOfProperty, PropertyName, Price, Type, Size, Address, SellerNo, DateListed) " +
                            "VALUES (@BuyerID, @ID, @SellID, @SellerName, @PicOfProperty, @PropertyName, @Price, @Type, @Size, @Address, @SellerNo, GETDATE())", conn);

                        // Convert loggedInUserId to integer since BuyerID is now INT NOT NULL
                        int buyerId = Convert.ToInt32(loggedInUserId);

                        insertCmd.Parameters.AddWithValue("@BuyerID", buyerId);
                        insertCmd.Parameters.AddWithValue("@ID", buyerId);    // Storing the buyer's ID here
                        insertCmd.Parameters.AddWithValue("@SellID", sellIdValue);   // Adding the SellID from the original property
                        insertCmd.Parameters.AddWithValue("@SellerName", sellerName);
                        insertCmd.Parameters.AddWithValue("@PicOfProperty", picOfProperty);
                        insertCmd.Parameters.AddWithValue("@PropertyName", propertyName);
                        insertCmd.Parameters.AddWithValue("@Price", price);
                        insertCmd.Parameters.AddWithValue("@Type", type);
                        insertCmd.Parameters.AddWithValue("@Size", size);
                        insertCmd.Parameters.AddWithValue("@Address", address);
                        insertCmd.Parameters.AddWithValue("@SellerNo", sellerNo);

                        int rowsAffected = insertCmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            // Success message
                            string script = "alert('Property added to your profile successfully!');";
                            ScriptManager.RegisterStartupScript(this, GetType(), "AddSuccess", script, true);
                        }
                        else
                        {
                            Response.Write("<script>alert('Failed to add property to your profile.');</script>");
                        }
                    }
                    else
                    {
                        reader.Close();
                        Response.Write("<script>alert('Property details not found.');</script>");
                    }
                }
                catch (Exception ex)
                {
                    Response.Write("<script>alert('Error: " + ex.Message.Replace("'", "\\'") + "');</script>");
                }
            }
        }
    }
}