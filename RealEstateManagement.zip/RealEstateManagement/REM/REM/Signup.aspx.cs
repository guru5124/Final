﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace REM
{
    public partial class Signup : System.Web.UI.Page
    {
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (rblUserType == null || txtUsername == null || txtEmail == null || txtPassword == null || txtAadhar == null || lblMessage == null)
            {
                Response.Write("One or more controls are not initialized. Check your ASPX file.");
                return;
            }

            string userType = rblUserType.SelectedValue;
            string username = txtUsername.Text;
            string email = txtEmail.Text;
            string password = txtPassword.Text;
            string phno = txtPhNo.Text;
            string aadhar = txtAadhar.Text;

            string connString = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connString))
            {
                string query = "INSERT INTO Users (UserType, Username, Email, Password, PhNo, Aadhar) VALUES (@UserType, @Username, @Email, @Password, @PhNo, @Aadhar)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@UserType", userType);
                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Password", password);
                cmd.Parameters.AddWithValue("@PhNo", phno);
                cmd.Parameters.AddWithValue("@Aadhar", aadhar);

                con.Open();
                int result = cmd.ExecuteNonQuery();
                lblMessage.Text = result > 0 ? "Registration successful!" : "Error in registration.";

                if (result > 0)
                {
                    Response.Redirect("Login.aspx");
                }
            }
        }
    }
}
