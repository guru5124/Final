﻿using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace REM
{
    public partial class Sell : System.Web.UI.Page
    {
        private string loggedInUserId = "";
        private bool isEditMode = false;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Check if user is logged in (in a real application, this would use Session)
            loggedInUserId = Session["UserID"] != null ? Session["UserID"].ToString() : "14"; // Default for testing

            if (!IsPostBack)
            {
                // Fill user data
                LoadUserData();

                // Check if editing an existing property
                if (Request.QueryString["id"] != null)
                {
                    isEditMode = true;
                    string propertyId = Request.QueryString["id"];
                    hdnPropertyID.Value = propertyId;
                    LoadPropertyData(propertyId);

                    // Change title and button text for edit mode
                    Page.Title = "Edit Property";
                    btnSubmit.Text = "Update";
                }

                // Make image upload not required in edit mode
                rfvPropertyImage.Enabled = !isEditMode;
            }
        }

        private void LoadUserData()
        {
            string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT ID, Username FROM Users WHERE ID=@ID", conn);
                    cmd.Parameters.AddWithValue("@ID", loggedInUserId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        txtUserID.Text = reader["ID"].ToString();
                        txtUsername.Text = reader["Username"].ToString();
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    ShowMessage("Error loading user data: " + ex.Message, false);
                }
            }
        }

        private void LoadPropertyData(string propertyId)
        {
            string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT * FROM Sell WHERE SellID=@SellID AND ID=@ID", conn);
                    cmd.Parameters.AddWithValue("@SellID", propertyId);
                    cmd.Parameters.AddWithValue("@ID", loggedInUserId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        txtPropertyName.Text = reader["PropertyName"].ToString();
                        ddlPropertyType.SelectedValue = reader["Type"].ToString();
                        txtPropertySize.Text = reader["Size"].ToString();
                        txtAddress.Text = reader["Address"].ToString();
                        txtContactNo.Text = reader["SellerNo"].ToString();

                        // Display current image info
                        string currentImagePath = reader["PicOfProperty"].ToString();
                        if (!string.IsNullOrEmpty(currentImagePath))
                        {
                            lblImageStatus.Text = "Current image: " + Path.GetFileName(currentImagePath);
                            lblImageStatus.Visible = true;
                        }
                    }
                    else
                    {
                        // Property not found or doesn't belong to this user
                        Response.Redirect("Account.aspx");
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    ShowMessage("Error loading property data: " + ex.Message, false);
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    if (isEditMode)
                    {
                        UpdateExistingProperty(); // Add this method for editing properties
                    }
                    else
                    {
                        AddNewProperty();
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the error and show a user-friendly message
                ShowMessage("An error occurred while processing your request: " + ex.Message, false);
            }
        }

        private void AddNewProperty()
        {
            // Image validation logic
            if (!isEditMode && !fuPropertyImage.HasFile)
            {
                ShowMessage("Please select an image file for the property.", false);
                return;
            }

            string imagePath = "";
            if (fuPropertyImage.HasFile)
            {
                // Upload the image
                imagePath = UploadPropertyImage();
                if (string.IsNullOrEmpty(imagePath) && !isEditMode)
                {
                    return; // Error occurred during upload and not in edit mode
                }
            }
            else if (isEditMode)
            {
                // Keep existing image in edit mode
                imagePath = lblImageStatus.Text.Replace("Current image: ", "");
            }

            // Save the property data
            string connStr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd;

                    if (isEditMode)
                    {
                        cmd = new SqlCommand(
                            "UPDATE Sell SET SellerName=@SellerName, PropertyName=@PropertyName, " +
                            "Price=@Price, Type=@Type, Size=@Size, Address=@Address, SellerNo=@SellerNo " +
                            (fuPropertyImage.HasFile ? ", PicOfProperty=@PicOfProperty " : "") +
                            "WHERE SellID=@SellID AND ID=@ID", conn);

                        cmd.Parameters.AddWithValue("@SellID", hdnPropertyID.Value);
                    }
                    else
                    {
                        cmd = new SqlCommand(
                            "INSERT INTO Sell (ID, SellerName, PicOfProperty, PropertyName, Price, Type, Size, Address, SellerNo) " +
                            "VALUES (@ID, @SellerName, @PicOfProperty, @PropertyName, @Price, @Type, @Size, @Address, @SellerNo)", conn);

                        cmd.Parameters.AddWithValue("@PicOfProperty", imagePath);
                    }

                    cmd.Parameters.AddWithValue("@ID", txtUserID.Text);
                    cmd.Parameters.AddWithValue("@SellerName", txtUsername.Text);
                    cmd.Parameters.AddWithValue("@PropertyName", txtPropertyName.Text);
                    cmd.Parameters.AddWithValue("@Price", txtPrice.Text);
                    cmd.Parameters.AddWithValue("@Type", ddlPropertyType.SelectedValue);
                    cmd.Parameters.AddWithValue("@Size", txtPropertySize.Text);
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@SellerNo", txtContactNo.Text);

                    if (isEditMode && fuPropertyImage.HasFile)
                    {
                        cmd.Parameters.AddWithValue("@PicOfProperty", imagePath);
                    }

                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        // Successfully added/updated
                        // Make sure we preserve the session when redirecting
                        Session["redirectedFromSell"] = true;
                        Response.Redirect("Account.aspx", false);
                        Context.ApplicationInstance.CompleteRequest();
                    }
                    else
                    {
                        ShowMessage("Failed to " + (isEditMode ? "update" : "add") + " the property. Please try again.", false);
                    }
                }
                catch (Exception ex)
                {
                    ShowMessage("Error " + (isEditMode ? "updating" : "adding") + " property: " + ex.Message, false);
                }
            }
        }

        // Add this method to handle property updates
        private void UpdateExistingProperty()
        {
            // Reuse the AddNewProperty method since we've updated it to handle both cases
            AddNewProperty();
        }

        private string UploadPropertyImage()
        {
            try
            {
                if (!fuPropertyImage.HasFile)
                {
                    ShowMessage("Please select an image file.", false);
                    return string.Empty;
                }

                string fileName = Path.GetFileName(fuPropertyImage.FileName);
                string extension = Path.GetExtension(fileName).ToLower();

                // Validate file extension
                string[] allowedExtensions = { ".jpg", ".jpeg", ".png", ".gif" };
                if (!Array.Exists(allowedExtensions, e => e == extension))
                {
                    ShowMessage("Only image files (.jpg, .jpeg, .png, .gif) are allowed.", false);
                    return string.Empty;
                }

                // Get the absolute path to the Images/Properties directory
                string folderPath = Server.MapPath("~/Images/");

                // Create directory if it doesn't exist
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                // Add timestamp to filename to avoid caching issues
                string timestamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                string uniqueFileName = Path.GetFileNameWithoutExtension(fileName) + "_" + timestamp + extension;
                string filePath = "~/Images/" + uniqueFileName;
                string fullPath = Server.MapPath(filePath);

                // Check if we can write to this location
                try
                {
                    // Make sure the directory has write permissions
                    File.WriteAllText(Path.Combine(folderPath, "test.txt"), "test");
                    File.Delete(Path.Combine(folderPath, "test.txt"));
                }
                catch (Exception ex)
                {
                    ShowMessage("Error: Unable to write to the destination folder. Please check permissions: " + ex.Message, false);
                    return string.Empty;
                }

                // Save the file
                try
                {
                    fuPropertyImage.SaveAs(fullPath);
                    if (!File.Exists(fullPath))
                    {
                        ShowMessage("Error: File was not saved successfully to " + fullPath, false);
                        return string.Empty;
                    }
                }
                catch (Exception ex)
                {
                    ShowMessage("Error saving file: " + ex.Message, false);
                    return string.Empty;
                }

                return filePath;
            }
            catch (Exception ex)
            {
                ShowMessage("Error uploading image: " + ex.Message, false);
                return string.Empty;
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("Account.aspx", false);
                Context.ApplicationInstance.CompleteRequest();
            }
            catch (Exception ex)
            {
                ShowMessage("Error navigating back: " + ex.Message, false);
            }
        }

        private void ShowMessage(string message, bool isSuccess)
        {
            lblMessage.Text = message;
            lblMessage.CssClass = isSuccess ? "message success" : "message error";
            lblMessage.Visible = true;
        }
    }
}