﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Mail;

namespace EmployeeManagementSystem
{
    public partial class signUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMessage.Text = ""; // Clear message on page load
        }

        protected void btnSignUp_Click(object sender, EventArgs e)
        {
            if (!IsValidEmail(txtEmail.Text.Trim()))
            {
                lblMessage.Text = "Please enter a valid Gmail address.";
                lblMessage.CssClass = "error";
                return;
            }

            if (txtPassword.Text.Trim() != txtConfirmPassword.Text.Trim())
            {
                lblMessage.Text = "Passwords do not match. Please try again.";
                lblMessage.CssClass = "error";
                return;
            }

            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string checkQuery = "SELECT COUNT(*) FROM Employees WHERE Email = @Email";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                        int userCount = (int)checkCommand.ExecuteScalar();

                        if (userCount > 0)
                        {
                            lblMessage.Text = "User Already Registered.";
                            lblMessage.CssClass = "error";
                            return;
                        }
                    }

                    string uniqueId = Guid.NewGuid().ToString();

                    string query = "INSERT INTO Employees (EmployeeFirstName, EmployeeMiddleName, EmployeeLastName, Email, CreatePassword, UniqueID) " +
                                   "VALUES (@FirstName, @MiddleName, @LastName, @Email, @Password, @UniqueID)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@FirstName", txtFirstName.Text.Trim());
                        command.Parameters.AddWithValue("@MiddleName", txtMiddleName.Text.Trim());
                        command.Parameters.AddWithValue("@LastName", txtLastName.Text.Trim());
                        command.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                        command.Parameters.AddWithValue("@Password", txtPassword.Text.Trim());
                        command.Parameters.AddWithValue("@UniqueID", uniqueId);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            lblMessage.Text = "Registration Successfully done. Wait for admin to confirm.";
                            lblMessage.CssClass = "success";

                            ClearForm();
                        }
                        else
                        {
                            lblMessage.Text = "Sign Up Failed. Please try again.";
                            lblMessage.CssClass = "error";
                        }
                    }
                }
                catch (Exception ex)
                {
                    lblMessage.Text = "Error: " + ex.Message;
                    lblMessage.CssClass = "error";
                }
            }
        }

        private bool IsValidEmail(string email)
        {
            // Regex to check if email ends with gmail.com
            string pattern = @"^[a-zA-Z0-9._%+-]+@gmail\.com$";
            return Regex.IsMatch(email, pattern);
        }

        private void ClearForm()
        {
            txtFirstName.Text = "";
            txtMiddleName.Text = "";
            txtLastName.Text = "";
            txtEmail.Text = "";
            txtPassword.Text = "";
            txtConfirmPassword.Text = "";
        }
    }
}
