﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;


namespace EmployeeManagementSystem
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblError.Text = ""; // Clear error message on page load
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;
            string usernameOrEmail = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (usernameOrEmail == "admin" && password == "admin")
            {
                Response.Redirect("http://localhost:41773/Home/adminHome.aspx");
            }
            else
            {
                string query = "SELECT UniqueID, EmployeeFirstName FROM ApprovedEmployees WHERE UniqueID = @UniqueID AND CreatePassword = @Password";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UniqueID", usernameOrEmail);
                        command.Parameters.AddWithValue("@Password", password);

                        try
                        {
                            connection.Open();
                            SqlDataReader reader = command.ExecuteReader();

                            if (reader.Read()) // If user exists
                            {
                                string uniqueId = reader["UniqueID"].ToString();
                                string firstName = reader["EmployeeFirstName"].ToString();

                                // Store in session
                                Session["UniqueID"] = uniqueId;
                                Session["FirstName"] = firstName;

                                Response.Redirect("http://localhost:41773/Employee/empHome.aspx");
                            }
                            else
                            {
                                lblError.Text = "Invalid email or password!";
                                lblError.Visible = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            lblError.Text = "Error: " + ex.Message;
                            lblError.Visible = true;
                        }
                    }
                }
            }
        }
    }
}