﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using Microsoft.Reporting.WebForms;

namespace EmployeeManagementSystem.Employee
{
    public partial class empLeave : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UniqueID"] == null)
                {
                    Response.Redirect("http://localhost:41773/Registration/login.aspx");
                }

                if (Session["ProfilePic"] != null)
                {
                    imgProfilePic.ImageUrl = Session["ProfilePic"].ToString();
                }
                else
                {
                    imgProfilePic.ImageUrl = "~/images/accountIcon.png"; // Default image
                }

                LoadLeaveReport();
            }
        }

        protected void btnApplyLeave_Click(object sender, EventArgs e)
        {
            if (Session["UniqueID"] == null || Session["FirstName"] == null)
            {
                lblMessage.Text = "Error: Please log in again.";
                return;
            }

            string uniqueId = Session["UniqueID"].ToString();
            string firstName = Session["FirstName"].ToString();
            string leaveType = ddlLeaveType.SelectedValue;
            string startDate = txtStartDate.Text;
            string endDate = txtEndDate.Text;
            string reason = txtReason.Text;

            if (string.IsNullOrEmpty(leaveType) || string.IsNullOrEmpty(startDate) || string.IsNullOrEmpty(endDate) || string.IsNullOrEmpty(reason))
            {
                lblMessage.Text = "All fields are required.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO EmployeeLeave (UniqueID, EmployeeFirstName, LeaveType, StartDate, EndDate, Reason, Status) " +
                               "VALUES (@UniqueID, @EmployeeFirstName, @LeaveType, @StartDate, @EndDate, @Reason, 'Pending')";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UniqueID", uniqueId);
                    cmd.Parameters.AddWithValue("@EmployeeFirstName", firstName);
                    cmd.Parameters.AddWithValue("@LeaveType", leaveType);
                    cmd.Parameters.AddWithValue("@StartDate", startDate);
                    cmd.Parameters.AddWithValue("@EndDate", endDate);
                    cmd.Parameters.AddWithValue("@Reason", reason);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }

            lblMessage.Text = "Leave request submitted successfully!";
            lblMessage.ForeColor = System.Drawing.Color.Green;

            // Clear the form fields
            ddlLeaveType.SelectedIndex = 0;
            txtStartDate.Text = "";
            txtEndDate.Text = "";
            txtReason.Text = "";
        }

        private void LoadLeaveReport()
        {
            if (Session["UniqueID"] == null)
            {
                Response.Redirect("~/Registration/login.aspx");
                return;
            }

            string uniqueID = Session["UniqueID"].ToString();
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

            DataTable dt = new DataTable();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"SELECT EmployeeFirstName, LeaveType, StartDate, EndDate, Reason, Status 
                         FROM EmployeeLeave 
                         WHERE UniqueID = @UniqueID"; // Filter by UniqueID

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UniqueID", uniqueID);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }

            if (dt.Rows.Count == 0)
            {
                lblMessage.Text = "No leave records found.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
            }

            // Bind the filtered data to the ReportViewer
            ReportViewer2.ProcessingMode = ProcessingMode.Local;
            ReportViewer2.LocalReport.ReportPath = Server.MapPath("~/Report/empLeaveReport.rdlc");

            ReportDataSource rds = new ReportDataSource("DataSet1", dt); // Ensure DataSet1 matches the rdlc dataset name
            ReportViewer2.LocalReport.DataSources.Clear();
            ReportViewer2.LocalReport.DataSources.Add(rds);
            ReportViewer2.LocalReport.Refresh();
        }

        protected void btnDownloadPDF_Click(object sender, EventArgs e)
        {
            ExportToPDF();
        }

        private void ExportToPDF()
        {
            Warning[] warnings;
            string[] streamIds;
            string mimeType, encoding, extension;

            // Render the report as a byte array
            byte[] bytes = ReportViewer2.LocalReport.Render(
                "PDF", null, out mimeType, out encoding, out extension, out streamIds, out warnings);

            // Send the PDF file to the user for download
            Response.Clear();
            Response.ContentType = "application/pdf";
            Response.AddHeader("Content-Disposition", "attachment; filename=LeaveReport.pdf");
            Response.BinaryWrite(bytes);
            Response.End();
        }

    }
}