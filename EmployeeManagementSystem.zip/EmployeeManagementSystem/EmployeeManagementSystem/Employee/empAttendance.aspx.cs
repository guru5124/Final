﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;

namespace EmployeeManagementSystem.Employee
{
    public partial class empAttendance : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UniqueID"] == null)
            {
                Response.Redirect("http://localhost:41773/Registration/login.aspx"); // Redirect if not logged in
            }

            if (!IsPostBack)
            {
                if (Session["ProfilePic"] != null)
                {
                    imgProfilePic.ImageUrl = Session["ProfilePic"].ToString();
                }
                else
                {
                    imgProfilePic.ImageUrl = "~/images/accountIcon.png"; // Default image
                }
                LoadReport();
            }
        }

        private void LoadReport()
        {
            string uniqueID = Session["UniqueID"].ToString();
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"
                    SELECT EmployeeFirstName, AttendanceDate, Status
                    FROM EmployeeAttendance
                    WHERE UniqueID = @UniqueID 
                    AND MONTH(AttendanceDate) = MONTH(GETDATE()) 
                    AND YEAR(AttendanceDate) = YEAR(GETDATE())
                    ORDER BY AttendanceDate DESC";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@UniqueID", uniqueID);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }

            // Set Report Viewer Properties
            ReportViewer1.ProcessingMode = ProcessingMode.Local;
            ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/empAttendance.rdlc");

            // Bind Data Source
            ReportDataSource rds = new ReportDataSource("DataSet1", dt);
            ReportViewer1.LocalReport.DataSources.Clear();
            ReportViewer1.LocalReport.DataSources.Add(rds);
            ReportViewer1.LocalReport.Refresh();
        }
    }
}