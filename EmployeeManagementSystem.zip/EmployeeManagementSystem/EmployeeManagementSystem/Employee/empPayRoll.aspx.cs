﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Microsoft.Reporting.WebForms;

namespace EmployeeManagementSystem.Employee
{
    public partial class empPayRoll : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["ProfilePic"] != null)
                {
                    imgProfilePic.ImageUrl = Session["ProfilePic"].ToString();
                }
                else
                {
                    imgProfilePic.ImageUrl = "~/images/accountIcon.png"; // Default image
                }

                LoadReport();
            }
        }

        private void LoadReport()
        {
                string UniqueID = Session["UniqueID"].ToString(); // Get EmployeeID from session
                string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM PayslipReports WHERE EmployeeID = @UniqueID";
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    da.SelectCommand.Parameters.AddWithValue("@UniqueID", UniqueID);

                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Configure ReportViewer
                    ReportViewer3.Visible = true;
                    ReportViewer3.ProcessingMode = ProcessingMode.Local;
                    ReportViewer3.LocalReport.ReportPath = Server.MapPath("/Report/empPaySlip.rdlc");

                    // Clear previous data sources
                    ReportViewer3.LocalReport.DataSources.Clear();

                    // Create new ReportDataSource and bind it
                    ReportDataSource rds = new ReportDataSource("DataSet1", dt);
                    ReportViewer3.LocalReport.DataSources.Add(rds);

                    // Refresh ReportViewer
                    ReportViewer3.LocalReport.Refresh();
                    ReportViewer3.DataBind();
                }
        }

        protected void btnDownloadPDF_Click(object sender, EventArgs e)
        {
            ExportToPDF();
        }

        private void ExportToPDF()
        {
            Warning[] warnings;
            string[] streamIds;
            string mimeType, encoding, extension;

            // Render the report as a byte array
            byte[] bytes = ReportViewer3.LocalReport.Render(
                "PDF", null, out mimeType, out encoding, out extension, out streamIds, out warnings);

            // Send the PDF file to the user for download
            Response.Clear();
            Response.ContentType = "application/pdf";
            Response.AddHeader("Content-Disposition", "attachment; filename=PayrollReport.pdf");
            Response.BinaryWrite(bytes);
            Response.End();
        }
    }
}