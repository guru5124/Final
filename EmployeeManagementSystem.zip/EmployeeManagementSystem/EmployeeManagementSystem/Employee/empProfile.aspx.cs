﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


namespace EmployeeManagementSystem.Employee
{
    public partial class empProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["ProfilePic"] != null)
                {
                    imgProfilePic.ImageUrl = Session["ProfilePic"].ToString();
                }
                else
                {
                    imgProfilePic.ImageUrl = "~/images/accountIcon.png"; // Default image
                }

                LoadEmployeeProfile();
            }
        }

        private void LoadEmployeeProfile()
        {
            // Keep all text fields empty for new entry
            txtGender.Text = "";
            txtAlterEmail.Text = "";
            txtPhone.Text = "";
            txtAddress.Text = "";
            txtCardNumber.Text = "";
            txtBankName.Text = "";
            txtIFSC.Text = "";

            // Set default profile picture
            imgProfilePic.ImageUrl = "~/images/accountIcon.png";
        }

        protected void btnSaveProfile_Click(object sender, EventArgs e)
        {
            string gender = txtGender.Text;
            string alterEmail = txtAlterEmail.Text;
            string phone = txtPhone.Text;
            string address = txtAddress.Text;
            string cardNumber = txtCardNumber.Text;
            string bankName = txtBankName.Text;
            string ifscCode = txtIFSC.Text;
            string profilePic = Session["ProfilePic"] != null ? Session["ProfilePic"].ToString() : "~/images/accountIcon.png";
            string uniqueId = Session["UniqueID"].ToString();

            string connString = System.Configuration.ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = @"UPDATE EmployeeProfile 
                         SET Gender = @Gender, AlternateEmail = @AlternateEmail, Phone = @Phone, 
                             Address = @Address, CardNumber = @CardNumber, BankName = @BankName, 
                             IFSCCode = @IFSCCode, ProfilePic = @ProfilePic
                         WHERE EmployeeID = @UniqueID"; // Replace 1 with actual EmployeeID

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@AlternateEmail", alterEmail);
                cmd.Parameters.AddWithValue("@Phone", phone);
                cmd.Parameters.AddWithValue("@Address", address);
                cmd.Parameters.AddWithValue("@CardNumber", cardNumber);
                cmd.Parameters.AddWithValue("@BankName", bankName);
                cmd.Parameters.AddWithValue("@IFSCCode", ifscCode);
                cmd.Parameters.AddWithValue("@ProfilePic", profilePic);
                cmd.Parameters.AddWithValue("@UniqueID", uniqueId);

                conn.Open();
                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    Response.Write("<script>alert('Profile updated successfully');</script>");
                }
                else
                {
                    Response.Write("<script>alert('Failed to update profile');</script>");
                }
            }
        }

        protected void btnUploadPic_Click(object sender, EventArgs e)
        {
            if (fuProfilePic.HasFile)
            {
                string uniqueId = Session["UniqueID"].ToString();
                string uploadFolder = Server.MapPath("~/images/ProfilePics/");

                // Ensure directory exists
                if (!Directory.Exists(uploadFolder))
                {
                    Directory.CreateDirectory(uploadFolder);
                }

                string fileName = Path.GetFileName(fuProfilePic.PostedFile.FileName);
                string savePath = Path.Combine(uploadFolder, fileName);

                fuProfilePic.SaveAs(savePath);

                string relativeImagePath = "~/images/ProfilePics/" + fileName;

                // Store image path in session
                Session["ProfilePic"] = relativeImagePath;
                imgProfilePic.ImageUrl = relativeImagePath;
            }
        }
    }
}