﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Microsoft.Reporting.WebForms;

namespace EmployeeManagementSystem.Employee
{
    public partial class empPerformance : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["ProfilePic"] != null)
                {
                    imgProfilePic.ImageUrl = Session["ProfilePic"].ToString();
                }
                else
                {
                    imgProfilePic.ImageUrl = "~/images/accountIcon.png"; // Default image
                }

                LoadPerformanceReport();
            }
        }

        private void LoadPerformanceReport()
        {
            string uniqueID = Session["UniqueID"].ToString(); // Get logged-in employee ID
            if (string.IsNullOrEmpty(uniqueID))
            {
                lblMessage.Text = "Error: No employee found.";
                return;
            }

            string connStr = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand("GetEmployeePerformance", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UniqueID", uniqueID);

                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        ReportViewer4.LocalReport.DataSources.Clear();
                        ReportViewer4.LocalReport.DataSources.Add(new ReportDataSource("DataSet1", dt));
                        ReportViewer4.LocalReport.ReportPath = Server.MapPath("/Report/empPerformance.rdlc");
                        ReportViewer4.LocalReport.Refresh();
                    }
                }
            }
        }
    }
}