﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

namespace EmployeeManagementSystem.Employee
{
    public partial class empHome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UniqueID"] == null)
            {
                Response.Redirect("http://localhost:41773/Registration/login.aspx"); // Redirect to login if session expired
            }

            if (!IsPostBack)
            {
                if (Session["FirstName"] != null)
                {
                    string firstName = Session["FirstName"].ToString();
                    profileText.InnerText = "Welcome, " + firstName;
                }

                if (Session["ProfilePic"] != null)
                {
                    imgProfilePic.ImageUrl = Session["ProfilePic"].ToString();
                }
                else
                {
                    imgProfilePic.ImageUrl = "~/images/accountIcon.png"; // Default image
                }
            }
        }

        protected void btnMarkAttendance_Click(object sender, EventArgs e)
        {
            // Get logged-in user details from session
            if (Session["UniqueID"] != null && Session["FirstName"] != null)
            {
                string uniqueId = Session["UniqueID"].ToString();
                string firstName = Session["FirstName"].ToString();

                string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO EmployeeAttendance (UniqueID, EmployeeFirstName, AttendanceDate, Status) VALUES (@UniqueID, @EmployeeFirstName, GETDATE(), 'Present')";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@UniqueID", uniqueId);
                    cmd.Parameters.AddWithValue("@EmployeeFirstName", firstName);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon(); // Destroy the session
            Session.Clear(); // Remove session variables
            Response.Redirect("http://localhost:41773/Registration/login.aspx"); // Redirect to login page
        }

        protected void btnLeave_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:41773/Employee/empLeave.aspx");
        }

        protected void btnPerform_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:41773/Employee/empPerformance.aspx");
        }

    }
}