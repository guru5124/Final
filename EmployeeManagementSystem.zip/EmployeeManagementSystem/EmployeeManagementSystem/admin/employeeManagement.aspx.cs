﻿using System;
using System.Text; 
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Data;
using Microsoft.Reporting.WebForms;

namespace EmployeeManagementSystem.admin
{
    public partial class employeeManagement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadEmployees();
                LoadApprovedEmployees();
                LoadLeaveReport();
            }
        }

        private void LoadEmployees()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Employees";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    gvEmployees.DataSource = cmd.ExecuteReader();
                    gvEmployees.DataBind();
                }
            }
        }

        protected void gvEmployees_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int employeeNo;
            if (!int.TryParse(e.CommandArgument.ToString(), out employeeNo))
                return;

            if (e.CommandName == "Approve")
            {
                ApproveEmployee(employeeNo);
            }
            else if (e.CommandName == "Cancel")
            {
                DeleteEmployee(employeeNo); // Only delete, don't add to Users table
            }
        }

        private void ApproveEmployee(int employeeNo)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Retrieve employee details
                string selectQuery = "SELECT EmployeeFirstName, EmployeeMiddleName, EmployeeLastName, Email, CreatePassword, UniqueID FROM Employees WHERE EmployeeNo = @EmployeeNo";
                SqlCommand selectCmd = new SqlCommand(selectQuery, conn);
                selectCmd.Parameters.AddWithValue("@EmployeeNo", employeeNo);

                SqlDataReader reader = selectCmd.ExecuteReader();
                if (reader.Read())
                {
                    string firstName = reader["EmployeeFirstName"].ToString();
                    string middleName = reader["EmployeeMiddleName"].ToString();
                    string lastName = reader["EmployeeLastName"].ToString();
                    string email = reader["Email"].ToString();
                    string password = reader["CreatePassword"].ToString();
                    string uniqueID = reader["UniqueID"].ToString();
                    reader.Close();

                    // Insert into ApprovedEmployees table
                    string insertApprovedQuery = @"
                INSERT INTO ApprovedEmployees (EmployeeFirstName, EmployeeMiddleName, EmployeeLastName, Email, CreatePassword, UniqueID) 
                VALUES (@FirstName, @MiddleName, @LastName, @Email, @Password, @UniqueID)";
                    SqlCommand insertApprovedCmd = new SqlCommand(insertApprovedQuery, conn);
                    insertApprovedCmd.Parameters.AddWithValue("@FirstName", firstName);
                    insertApprovedCmd.Parameters.AddWithValue("@MiddleName", middleName);
                    insertApprovedCmd.Parameters.AddWithValue("@LastName", lastName);
                    insertApprovedCmd.Parameters.AddWithValue("@Email", email);
                    insertApprovedCmd.Parameters.AddWithValue("@Password", password);
                    insertApprovedCmd.Parameters.AddWithValue("@UniqueID", uniqueID);
                    insertApprovedCmd.ExecuteNonQuery();

                    // Insert into Users table (Hash the password)
                    string insertUserQuery = "INSERT INTO Users (unique_id, password_hash) VALUES (@UniqueID, HASHBYTES('SHA2_256', @Password))";
                    SqlCommand insertUserCmd = new SqlCommand(insertUserQuery, conn);
                    insertUserCmd.Parameters.AddWithValue("@UniqueID", uniqueID);
                    insertUserCmd.Parameters.AddWithValue("@Password", password);
                    insertUserCmd.ExecuteNonQuery();
                    
                    // Delete from Employees table
                    DeleteEmployee(employeeNo);
                }
            }
        }

        private void DeleteEmployee(int employeeNo)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string deleteQuery = "DELETE FROM Employees WHERE EmployeeNo = @EmployeeNo";
                SqlCommand deleteCmd = new SqlCommand(deleteQuery, conn);
                deleteCmd.Parameters.AddWithValue("@EmployeeNo", employeeNo);
                deleteCmd.ExecuteNonQuery();

                // Reload the GridView
                LoadEmployees();
            }
        }

        private void LoadApprovedEmployees()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM ApprovedEmployees";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    gvApprovedEmployees.DataSource = cmd.ExecuteReader();
                    gvApprovedEmployees.DataBind();
                }
            }
        }

        // ✅ FIX: Handle RowCancelingEdit to prevent error
        protected void gvEmployees_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            LoadEmployees(); // Just rebind the data to exit edit mode
        }

        protected void btnManageEmployees_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:41773/Registration/signUp.aspx");
        }

        protected void gvApprovedEmployees_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DeleteEmployee")
            {
                string uniqueID = e.CommandArgument.ToString();
                DeleteApprovedEmployee(uniqueID);
            }
        }

        private void DeleteApprovedEmployee(string uniqueID)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string deleteQuery = "DELETE FROM ApprovedEmployees WHERE UniqueID = @UniqueID";
                SqlCommand deleteCmd = new SqlCommand(deleteQuery, conn);
                deleteCmd.Parameters.AddWithValue("@UniqueID", uniqueID);
                deleteCmd.ExecuteNonQuery();

                // Reload the GridView
                LoadApprovedEmployees();
            }
        }

        protected void btnDownloadPDF_Click(object sender, EventArgs e)
        {
            ExportToPDF();
        }

        private void ExportToPDF()
        {
            Warning[] warnings;
            string[] streamIds;
            string mimeType, encoding, extension;

            // Render the report as a byte array
            byte[] bytes = ReportViewer6.LocalReport.Render(
                "PDF", null, out mimeType, out encoding, out extension, out streamIds, out warnings);

            // Send the PDF file to the user for download
            Response.Clear();
            Response.ContentType = "application/pdf";
            Response.AddHeader("Content-Disposition", "attachment; filename=EmployeeReport.pdf");
            Response.BinaryWrite(bytes);
            Response.End();
        }

        private void LoadLeaveReport()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

            DataTable dt = new DataTable();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"SELECT ApprovedEmployeeNo, EmployeeFirstName, EmployeeMiddleName, EmployeeLastName, Email, UniqueID, ApprovalDate 
                         FROM ApprovedEmployees";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }

            // Bind the filtered data to the ReportViewer
            ReportViewer6.ProcessingMode = ProcessingMode.Local;
            ReportViewer6.LocalReport.ReportPath = Server.MapPath("~/Report/totalEmpReport.rdlc");

            ReportDataSource rds = new ReportDataSource("DataSet1", dt); // Ensure DataSet1 matches the rdlc dataset name
            ReportViewer6.LocalReport.DataSources.Clear();
            ReportViewer6.LocalReport.DataSources.Add(rds);
            ReportViewer6.LocalReport.Refresh();
        }
    }
}
