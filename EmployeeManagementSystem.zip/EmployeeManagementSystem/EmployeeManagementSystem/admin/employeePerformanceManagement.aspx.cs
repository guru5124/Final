﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EmployeeManagementSystem.admin
{
    public partial class employeePerformanceManagement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadPerformanceData();
            }
        }

        private void LoadPerformanceData()
        {
            string connStr = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = @"
                SELECT 
                    ea.UniqueID AS UniqueID, 
                    ea.EmployeeFirstName AS EmployeeName, 
                    COUNT(CASE WHEN ea.Status = 'Present' THEN 1 END) AS PresentDays, 
                    COUNT(ea.AttendanceDate) AS TotalWorkingDays,
                    (SELECT COUNT(*) FROM EmployeeLeave el WHERE el.UniqueID = ea.UniqueID AND el.Status = 'Approved') AS ApprovedLeaves
                FROM EmployeeAttendance ea
                GROUP BY ea.UniqueID, ea.EmployeeFirstName";

                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Add a Performance Score column
                dt.Columns.Add("PerformanceScore", typeof(string));

                foreach (DataRow row in dt.Rows)
                {
                    string uniqueID = row["UniqueID"].ToString();
                    string employeeName = row["EmployeeName"].ToString();
                    int presentDays = Convert.ToInt32(row["PresentDays"]);
                    int totalWorkingDays = Convert.ToInt32(row["TotalWorkingDays"]);
                    int approvedLeaves = Convert.ToInt32(row["ApprovedLeaves"]);

                    // Prevent division by zero
                    if (totalWorkingDays == 0) totalWorkingDays = 1;

                    // Performance Score Calculation
                    double performanceScore = 5 * (0.7 * (double)presentDays / totalWorkingDays + 0.3 * (double)approvedLeaves / 5);
                    performanceScore = Math.Round(performanceScore, 2);  // Round to 2 decimal places

                    row["PerformanceScore"] = performanceScore.ToString("0.00");
                    SavePerformanceScore(conn, uniqueID, employeeName, performanceScore);
                }

                gvPerformance.DataSource = dt;
                gvPerformance.DataBind();
            }
        }

        private void SavePerformanceScore(SqlConnection conn, string uniqueID, string employeeName, double score)
        {
            string query = @"
            IF EXISTS (SELECT 1 FROM EmployeePerformance WHERE UniqueID = @UniqueID)
                UPDATE EmployeePerformance SET PerformanceScore = @Score, UpdatedAt = GETDATE() WHERE UniqueID = @UniqueID;
            ELSE
                INSERT INTO EmployeePerformance (UniqueID, EmployeeName, PerformanceScore) VALUES (@UniqueID, @EmployeeName, @Score);";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@UniqueID", uniqueID);
                cmd.Parameters.AddWithValue("@EmployeeName", employeeName);
                cmd.Parameters.AddWithValue("@Score", score);
                cmd.ExecuteNonQuery();
            }
        }
    }
}