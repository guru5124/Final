﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace EmployeeManagementSystem.admin
{
    public partial class employeePayRollManagement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void txtEmployeeID_TextChanged(object sender, EventArgs e)
        {
            string empID = txtEmployeeID.Text.Trim();
            if (!string.IsNullOrEmpty(empID))
            {
                FetchEmployeeDetails(empID);
            }
        }


        private void FetchEmployeeDetails(string empID)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT EmployeeFirstName, EmployeeMiddleName, Email FROM ApprovedEmployees WHERE UniqueID = @EmployeeID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@EmployeeID", empID);

                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        txtFirstName.Text = reader["EmployeeFirstName"].ToString();
                        txtMiddleName.Text = reader["EmployeeMiddleName"].ToString();
                        txtEmail.Text = reader["Email"].ToString();
                    }
                    else
                    {
                        txtFirstName.Text = "";
                        txtMiddleName.Text = "";
                        txtEmail.Text = "";
                    }
                    con.Close();
                }
            }
        }

        protected void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                decimal basicSalary = Convert.ToDecimal(txtBasicSalary.Text);
                decimal deductions = Convert.ToDecimal(txtDeductions.Text);
                decimal bonuses = Convert.ToDecimal(txtBonuses.Text);

                decimal netSalary = basicSalary - deductions + bonuses;
                txtNetSalary.Text = netSalary.ToString("C"); // Format as currency
            }
            catch (Exception ex)
            {
                txtNetSalary.Text = "Error calculating salary";
            }
        }

        protected void btnGenerateReport_Click(object sender, EventArgs e)
        {
            // Trim input values to remove leading/trailing spaces
            string empID = txtEmployeeID.Text.Trim();
            string firstName = txtFirstName.Text.Trim();
            string middleName = txtMiddleName.Text.Trim();
            string email = txtEmail.Text.Trim();

            // Validate and parse numeric inputs
            decimal basicSalary, deductions, bonuses, netSalary;

            if (!decimal.TryParse(txtBasicSalary.Text.Trim(), out basicSalary))
            {
                txtNetSalary.Text = "Invalid Basic Salary";
                return;
            }
            if (!decimal.TryParse(txtDeductions.Text.Trim(), out deductions))
            {
                txtNetSalary.Text = "Invalid Deductions";
                return;
            }
            if (!decimal.TryParse(txtBonuses.Text.Trim(), out bonuses))
            {
                txtNetSalary.Text = "Invalid Bonuses";
                return;
            }

            // Calculate net salary
            netSalary = basicSalary - deductions + bonuses;
            txtNetSalary.Text = netSalary.ToString("0.00");

            // Save to database
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO PayslipReports (EmployeeID, FirstName, MiddleName, Email, BasicSalary, Deductions, Bonuses, NetSalary, DateGenerated) " +
                               "VALUES (@EmployeeID, @FirstName, @MiddleName, @Email, @BasicSalary, @Deductions, @Bonuses, @NetSalary, GETDATE())";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@EmployeeID", empID);
                    cmd.Parameters.AddWithValue("@FirstName", firstName);
                    cmd.Parameters.AddWithValue("@MiddleName", middleName);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@BasicSalary", basicSalary);
                    cmd.Parameters.AddWithValue("@Deductions", deductions);
                    cmd.Parameters.AddWithValue("@Bonuses", bonuses);
                    cmd.Parameters.AddWithValue("@NetSalary", netSalary);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
    }
}