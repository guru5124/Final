﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace EmployeeManagementSystem.admin
{
    public partial class employeeLeaveManagement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadLeaveRequests();
            }
        }

        private void LoadLeaveRequests()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"SELECT 
                            EL.ID, 
                            EL.UniqueID, 
                            AE.EmployeeFirstName AS EmployeeName, 
                            EL.LeaveType, 
                            EL.StartDate, 
                            EL.EndDate, 
                            EL.Reason, 
                            EL.Status
                        FROM EmployeeLeave EL
                        INNER JOIN ApprovedEmployees AE ON EL.UniqueID = AE.UniqueID
                        WHERE EL.Status = 'Pending'";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    gvLeaveRequests.DataSource = dt;
                    gvLeaveRequests.DataBind();
                }
            }
        }

        protected void gvLeaveRequests_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Approve" || e.CommandName == "Reject")
            {
                int leaveID;

                if (int.TryParse(e.CommandArgument.ToString(), out leaveID)) // Convert safely
                {
                    string status = e.CommandName == "Approve" ? "Approved" : "Rejected";

                    string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        string query = "UPDATE EmployeeLeave SET Status = @Status WHERE ID = @LeaveID";

                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Status", status);
                            cmd.Parameters.AddWithValue("@LeaveID", leaveID); // Fixed

                            conn.Open();
                            cmd.ExecuteNonQuery();
                        }
                    }

                    lblMessage.Text = "Leave ID " + leaveID + " has been " + status;
                    LoadLeaveRequests(); // Refresh GridView
                }
                else
                {
                    lblMessage.Text = "Error: Invalid Leave ID.";
                }
            }
        }
    }
}