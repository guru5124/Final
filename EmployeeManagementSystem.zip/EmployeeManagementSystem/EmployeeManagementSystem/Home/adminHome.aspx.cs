﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace EmployeeManagementSystem.Home
{
    public partial class adminHome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadTotalPendingUsersCount();
                LoadTotalUsersCount();
            }
        }

        private void LoadTotalPendingUsersCount()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;
            int totalUsers = 0;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM Employees"; // Get total number of users

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        totalUsers = (int)command.ExecuteScalar();
                    }
                }
                catch (Exception ex)
                {
                    Response.Write("Cannot Load Requests." + ex);
                }
            }

            lblTotalPendingRequest.Text = totalUsers.ToString(); // Assign count to label
        }

        private void LoadTotalUsersCount()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeDBConnectionString"].ConnectionString;
            int totalUsers = 0;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM ApprovedEmployees"; // Get total number of users

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        totalUsers = (int)command.ExecuteScalar();
                    }
                }
                catch (Exception ex)
                {
                    Response.Write("Cannot Load Requests." + ex);
                }
            }

            lblTotalUsers.Text = totalUsers.ToString(); // Assign count to label
        }
        protected void btnManageRequests_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:41773/admin/employeeManagement.aspx");
        }

        protected void btnManageEmployees_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:41773/admin/employeeManagement.aspx");
        }
    }
}